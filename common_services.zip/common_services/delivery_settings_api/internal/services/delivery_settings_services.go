package services

import (
	"context"

	"gitlab.wildberries.ru/wbwh/deliverysettings/backend/wh-delivery-settings.git/delivery_settings_api/internal/constant"
	"gitlab.wildberries.ru/wbwh/deliverysettings/backend/wh-delivery-settings.git/delivery_settings_api/internal/models"
	"gitlab.wildberries.ru/wbwh/deliverysettings/backend/wh-delivery-settings.git/delivery_settings_api/internal/storage"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
)

type deliverySettingsSrv struct {
	pgStorage storage.PgStorage
}

func NewDeliverySettingsSrv(pgStorage storage.PgStorage) *deliverySettingsSrv {
	return &deliverySettingsSrv{
		pgStorage: pgStorage,
	}
}

func (d deliverySettingsSrv) SettingsMassUpdateRoutesService(_ context.Context, data *models.DataFromRequestSettingsMassUpdateRoutes) rest_data.RestData {
	const (
		sp = "lgx.deliverysetting_updroute"
	)

	rd := d.pgStorage.ProcedureAccessingToDB(constant.DeliverySettingsPgx, sp, data.SrcOfficeArray, data.DstOfficeArray, data.RouteGroupID, data.EmployeeID)

	return rd
}

func (d deliverySettingsSrv) SettingsGetService(_ context.Context, data *models.DataFromRequestSettingsGet) rest_data.RestData {
	const (
		sp = "lgx.deliverysetting_getselfonly_v1"
	)

	rd := d.pgStorage.FunctionAccessingToDB(constant.DeliverySettingsPgx, sp, models.DataFromResponseSettingsGet{}, data.SrcOfficeID, data.DstOfficeIDs, data.RouteID)

	return rd
}

func (d deliverySettingsSrv) SettingsCopyByCreateService(_ context.Context, data *models.DataFromRequestSettingsCopy) rest_data.RestData {
	const (
		sp = "lgx.deliverysetting_transferbyoffice"
	)
	rd := d.pgStorage.ProcedureAccessingToDB(constant.DeliverySettingsPgx, sp, data.NewOfficeID, data.OldOfficeID, data.EmployeeID, data.ExceptionOfficeIDs, data.TargetOfficeIDs)

	return rd
}

func (d deliverySettingsSrv) SettingsUpdateService(_ context.Context, data *models.DataFromRequestSettingsUpdate) rest_data.RestData {
	const (
		sp = "lgx.deliverysetting_upd"
	)
	rd := d.pgStorage.ProcedureAccessingToDB(constant.DeliverySettingsPgx, sp, data.SrcOfficeID, data.DstOfficeArray, data.ParkingNum, data.RouteID, data.ShippingWhID, data.EmployeeID)

	return rd
}

func (d deliverySettingsSrv) SettingCreateService(_ context.Context, data *models.DataFromRequestSettingCreate) rest_data.RestData {
	const (
		sp = "lgx.deliverysetting_add"
	)
	rd := d.pgStorage.ProcedureAccessingToDB(constant.DeliverySettingsPgx, sp, data.SrcOfficeID, data.DstOfficeArray, data.ParkingNum, data.RouteGroupID, data.ShippingWhID, data.EmployeeID)

	return rd
}

func (d deliverySettingsSrv) SrcOfficesDictionaryAddService(_ context.Context, data *models.DataFromRequestSrcOfficesDictionaryAdd) rest_data.RestData {
	const (
		sp = "lgx.officeforfullchanges_add"
	)
	rd := d.pgStorage.ProcedureAccessingToDB(constant.DeliverySettingsPgx, sp, data.OfficeID, data.EmployeeID)

	return rd
}

func (d deliverySettingsSrv) SrcOfficesDictionaryDeleteService(_ context.Context, data *models.DataFromRequestSrcOfficesDictionaryDelete) rest_data.RestData {
	const (
		sp = "lgx.officeforfullchanges_del"
	)
	rd := d.pgStorage.ProcedureAccessingToDB(constant.DeliverySettingsPgx, sp, data.OfficeID, data.EmployeeID)

	return rd
}

func (d deliverySettingsSrv) SrcOfficesDictionaryGetService(_ context.Context) rest_data.RestData {
	const (
		sp = "lgx.officeforfullchanges_getall"
	)
	rd := d.pgStorage.FunctionAccessingToDBWithoutParams(constant.DeliverySettingsPgx, sp)

	return rd
}

func (d deliverySettingsSrv) SettingsBySrcOfficeUpdateAllService(_ context.Context, data *models.DataFromRequestSettingsBySrcOfficeUpdateAll) rest_data.RestData {
	const (
		sp = "lgx.deliverysetting_updfulloffice"
	)
	rd := d.pgStorage.ProcedureAccessingToDB(constant.DeliverySettingsPgx, sp, data.SrcOfficeID, data.ParkingNum, data.RouteID, data.ShippingWhID, data.EmployeeID)

	return rd
}

func (d deliverySettingsSrv) SettingsCopyByUpdateService(_ context.Context, data *models.DataFromRequestSettingsCopy) rest_data.RestData {
	const (
		sp = "lgx.deliverysetting_copybyoffice"
	)
	rd := d.pgStorage.ProcedureAccessingToDB(constant.DeliverySettingsPgx, sp, data.NewOfficeID, data.OldOfficeID, data.EmployeeID, data.ExceptionOfficeIDs, data.TargetOfficeIDs)

	return rd
}

func (d deliverySettingsSrv) SettingsGetAllService(_ context.Context, data *models.DataFromRequestSettingsGetAll) rest_data.RestData {
	const (
		sp = "lgx.deliverysetting_get_v1"
	)

	rd := d.pgStorage.FunctionAccessingToDB(constant.DeliverySettingsPgx, sp, models.DataFromResponseSettingsGetAll{}, data.SrcOfficeID, data.DstOfficeID, data.RouteID, data.WithClosedDstOffices)

	return rd
}

func (d deliverySettingsSrv) SettingsDeleteService(_ context.Context, data *[]models.DataFromRequestSettingsDelete, employeeID int64) rest_data.RestData {
	const (
		sp = "lgx.deliverysetting_del_v2"
	)

	rd := d.pgStorage.ProcedureAccessingToDB(constant.DeliverySettingsPgx, sp, data, employeeID)

	return rd
}

func (d deliverySettingsSrv) RoutesByRouteIdsGetService(_ context.Context, data *models.DataFromRequestRoutesByRouteIdsGet) rest_data.RestData {
	const (
		sp = "lgx.shippingroute_getbyids"
	)

	rd := d.pgStorage.FunctionAccessingToDBWithoutError(constant.DeliverySettingsPgx, sp, data.RouteIDs)

	return rd
}

func (d deliverySettingsSrv) SettingsUpdateWithHiddenService(_ context.Context, data *models.DataFromRequestSettingsUpdateWithHidden) rest_data.RestData {
	const (
		sp = "lgx.deliverysetting_updwithhidden"
	)

	rd := d.pgStorage.ProcedureAccessingToDB(constant.DeliverySettingsPgx, sp, data.SrcOfficeID, data.DstOfficeID, data.ParkingNum, data.RouteID, data.ShippingWhID, data.EmployeeID)

	return rd
}

func (d deliverySettingsSrv) DstOfficeWithWrongRoutesGetService(_ context.Context) rest_data.RestData {
	const (
		sp = "lgx.dstofficewithwrongroutes_get"
	)

	rd := d.pgStorage.FunctionAccessingToDBWithoutError(constant.DeliverySettingsPgx, sp)

	return rd
}

func (d deliverySettingsSrv) DstOfficeWithWrongRoutesDeleteService(_ context.Context, data *models.DataFromRequestDstOfficeWithWrongRoutesDelete) rest_data.RestData {
	const (
		sp = "lgx.dstofficewithwrongroutes_del"
	)

	rd := d.pgStorage.ProcedureAccessingToDB(constant.DeliverySettingsPgx, sp, data.DstOfficeID)

	return rd
}
