package storage

import (
	"encoding/json"
	"errors"
	"net/http"

	jsoniter "github.com/json-iterator/go"

	local_errors "gitlab.wildberries.ru/wbwh/deliverysettings/backend/wh-delivery-settings.git/delivery_settings_api/internal/errors"
	"gitlab.wildberries.ru/wbwh/deliverysettings/backend/wh-delivery-settings.git/delivery_settings_api/internal/models"
	delivery_utils "gitlab.wildberries.ru/wbwh/deliverysettings/utils.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_database.git/postgresql"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_database.git/postgresql/repository"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
	core_utils "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors"
	error_keys "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors/errors_keys"
)

type PgStorage interface {
	ProcedureAccessingToDB(dbNAme, sp string, params ...any) rest_data.RestData
	FunctionAccessingToDB(dbNAme, sp string, response any, params ...any) rest_data.RestData
	FunctionAccessingToDBWithoutParams(dbNAme, sp string) rest_data.RestData
	FunctionAccessingToDBWithoutError(dbNAme, sp string, params ...any) rest_data.RestData
}

type pgStorage struct {
	errBuilder core_utils.ErrorBuilder
}

func NewPgStorage(errBuilder core_utils.ErrorBuilder) PgStorage {
	return &pgStorage{
		errBuilder: errBuilder,
	}
}

func (p *pgStorage) ProcedureAccessingToDB(dbNAme, sp string, params ...any) rest_data.RestData {
	pg := new(postgresql.PgSpec)
	pg.SetDatabaseKey(dbNAme)
	pg.SetStoredProcedureName(sp)
	pg.SetUseProcedure()
	pg.SetParams(params...)

	if err := repository.Execute(pg); err != nil {
		return delivery_utils.ParseProcedureError(err)
	}

	return rest_data.RestData{HttpResultCode: http.StatusNoContent}
}

func (p *pgStorage) FunctionAccessingToDB(dbNAme, sp string, response any, params ...any) rest_data.RestData {
	pg := new(postgresql.PgSpec)
	pg.SetDatabaseKey(dbNAme)
	pg.SetParams(params...)
	pg.SetStoredProcedureName(sp)
	pg.SetUseFunction()

	switch response.(type) {
	case models.DataFromResponseSettingsGet:
		var data models.DataFromResponseSettingsGet
		dbResp, err := repository.ReadStructSlice[models.DataFromResponseSettingsGet](pg, data)
		if err != nil {
			return delivery_utils.ParseProcedureError(err)
		}
		if len(dbResp) == 0 {
			return rest_data.RestData{HttpResultCode: http.StatusNoContent}
		}

		jsonData, err := jsoniter.Marshal(dbResp)
		if err != nil {
			return p.errBuilder.BuildError(error_keys.Err500ReadDbResponseWrong, err)
		}

		rawMessage := json.RawMessage(jsonData)
		return rest_data.RestData{HttpResultCode: http.StatusOK, Data: &rawMessage}
	case models.DataFromResponseSettingsGetAll:
		var data models.DataFromResponseSettingsGetAll
		dbResp, err := repository.ReadStructSlice[models.DataFromResponseSettingsGetAll](pg, data)
		if err != nil {
			return delivery_utils.ParseProcedureError(err)
		}
		if len(dbResp) == 0 {
			return rest_data.RestData{HttpResultCode: http.StatusNoContent}
		}

		jsonData, err := jsoniter.Marshal(dbResp)
		if err != nil {
			return p.errBuilder.BuildError(error_keys.Err500ConvertTypeWrong, err)
		}

		rawMessage := json.RawMessage(jsonData)
		return rest_data.RestData{HttpResultCode: http.StatusOK, Data: &rawMessage}
	default:
		return p.errBuilder.BuildError(error_keys.Err500ConvertTypeWrong, errors.New(local_errors.UnsupportedtType))
	}
}

func (p *pgStorage) FunctionAccessingToDBWithoutParams(dbNAme, sp string) rest_data.RestData {
	pg := new(postgresql.PgSpec)
	pg.SetDatabaseKey(dbNAme)
	pg.SetStoredProcedureName(sp)
	pg.SetUseFunction()

	rd := repository.GetRestDataFromDb(pg)

	return rd
}

func (p *pgStorage) FunctionAccessingToDBWithoutError(dbNAme, sp string, params ...any) rest_data.RestData {
	pg := new(postgresql.PgSpec)
	pg.SetDatabaseKey(dbNAme)
	pg.SetParams(params...)
	pg.SetStoredProcedureName(sp)
	pg.SetUseFunction()

	rd := repository.GetRestDataFromDb(pg)

	return rd
}
