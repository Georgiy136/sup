package errors

const (
	UnsupportedtType = "unsupported type"
	EmptyBody        = "passed empty body"
)
