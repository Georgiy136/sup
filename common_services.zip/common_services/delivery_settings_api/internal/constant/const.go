package constant

const (
	DeliverySettingsPgx = "delivery_settings_pgx"
)
