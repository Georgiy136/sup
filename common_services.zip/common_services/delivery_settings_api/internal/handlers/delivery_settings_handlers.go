package handlers

import (
	"context"
	"errors"

	local_errors "gitlab.wildberries.ru/wbwh/deliverysettings/backend/wh-delivery-settings.git/delivery_settings_api/internal/errors"
	"gitlab.wildberries.ru/wbwh/deliverysettings/backend/wh-delivery-settings.git/delivery_settings_api/internal/models"
	deliveryutils "gitlab.wildberries.ru/wbwh/deliverysettings/utils.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_rest_auto_api.git/validators"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
	core_utils "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors"
	error_keys "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors/errors_keys"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_validators.git"

	"github.com/gin-gonic/gin"
	"github.com/go-playground/validator/v10"
)

type DeliverySettingsSrv interface {
	SettingsMassUpdateRoutesService(ctx context.Context, data *models.DataFromRequestSettingsMassUpdateRoutes) rest_data.RestData
	SettingsGetService(ctx context.Context, data *models.DataFromRequestSettingsGet) rest_data.RestData
	SettingsCopyByCreateService(ctx context.Context, data *models.DataFromRequestSettingsCopy) rest_data.RestData
	SettingsCopyByUpdateService(ctx context.Context, data *models.DataFromRequestSettingsCopy) rest_data.RestData
	SettingsUpdateService(ctx context.Context, data *models.DataFromRequestSettingsUpdate) rest_data.RestData
	SettingCreateService(ctx context.Context, data *models.DataFromRequestSettingCreate) rest_data.RestData
	SrcOfficesDictionaryAddService(ctx context.Context, data *models.DataFromRequestSrcOfficesDictionaryAdd) rest_data.RestData
	SrcOfficesDictionaryDeleteService(ctx context.Context, data *models.DataFromRequestSrcOfficesDictionaryDelete) rest_data.RestData
	SrcOfficesDictionaryGetService(ctx context.Context) rest_data.RestData
	SettingsBySrcOfficeUpdateAllService(ctx context.Context, data *models.DataFromRequestSettingsBySrcOfficeUpdateAll) rest_data.RestData
	SettingsGetAllService(ctx context.Context, data *models.DataFromRequestSettingsGetAll) rest_data.RestData
	SettingsDeleteService(ctx context.Context, data *[]models.DataFromRequestSettingsDelete, employeeID int64) rest_data.RestData
	RoutesByRouteIdsGetService(ctx context.Context, data *models.DataFromRequestRoutesByRouteIdsGet) rest_data.RestData
	SettingsUpdateWithHiddenService(ctx context.Context, data *models.DataFromRequestSettingsUpdateWithHidden) rest_data.RestData
	DstOfficeWithWrongRoutesGetService(ctx context.Context) rest_data.RestData
	DstOfficeWithWrongRoutesDeleteService(_ context.Context, data *models.DataFromRequestDstOfficeWithWrongRoutesDelete) rest_data.RestData
}

type deliverySettingsHandler struct {
	validator           *validator.Validate
	deliverySettingsSrv DeliverySettingsSrv
	errBuilder          core_utils.ErrorBuilder
}

func NewDeliverySettingsHandler(deliverySettingsSrv DeliverySettingsSrv, errBuilder core_utils.ErrorBuilder, valid *validator.Validate) *deliverySettingsHandler {
	gocore_validators.InitializeCustomValidatorsV10(valid)

	return &deliverySettingsHandler{
		validator:           valid,
		deliverySettingsSrv: deliverySettingsSrv,
		errBuilder:          errBuilder,
	}
}

func (d deliverySettingsHandler) SettingsMassUpdateRoutesHandler(ctx *gin.Context, params map[string]any) {
	queryRequest, err := deliveryutils.CastQuery[models.Common](params)
	if err != nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, err)
		return
	}

	bodyRequest, ok := params[validators.BodyValidatorBODY].(*struct {
		SrcOfficeArray []int64 `json:"src_office_array" binding:"required,dive,OfficeID"`
		DstOfficeArray []int64 `json:"dst_office_array" binding:"required,dive,OfficeID"`
		RouteGroupID   int64   `json:"routegroup_id" binding:"required,gt=0"`
	})
	if !ok {
		d.errBuilder.BindError(ctx, error_keys.Err500ConvertTypeWrong, errors.New(local_errors.UnsupportedtType))
		return
	}
	if bodyRequest == nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, errors.New(local_errors.EmptyBody))
		return
	}

	rd := d.deliverySettingsSrv.SettingsMassUpdateRoutesService(ctx, &models.DataFromRequestSettingsMassUpdateRoutes{
		SrcOfficeArray: bodyRequest.SrcOfficeArray,
		DstOfficeArray: bodyRequest.DstOfficeArray,
		RouteGroupID:   bodyRequest.RouteGroupID,
		EmployeeID:     queryRequest.EmployeeID,
	})

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}

func (d deliverySettingsHandler) SettingsGetHandler(ctx *gin.Context, params map[string]any) {
	bodyRequest, ok := params[validators.BodyValidatorBODY].(*struct {
		SrcOfficeID  *int64  `json:"src_office_id" binding:"omitempty,OfficeID"`
		DstOfficeIDs []int64 `json:"dst_office_ids" binding:"omitempty,dive,OfficeID"`
		RouteID      *int64  `json:"route_id" binding:"omitempty,LteInt32"`
	})
	if !ok {
		d.errBuilder.BindError(ctx, error_keys.Err500ConvertTypeWrong, errors.New(local_errors.UnsupportedtType))
		return
	}
	if bodyRequest == nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, errors.New(local_errors.EmptyBody))
		return
	}

	rd := d.deliverySettingsSrv.SettingsGetService(ctx, &models.DataFromRequestSettingsGet{
		SrcOfficeID:  bodyRequest.SrcOfficeID,
		DstOfficeIDs: bodyRequest.DstOfficeIDs,
		RouteID:      bodyRequest.RouteID,
	})

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}

func (d deliverySettingsHandler) SettingsCopyByCreateHandler(ctx *gin.Context, params map[string]any) {
	queryRequest, err := deliveryutils.CastQuery[models.Common](params)
	if err != nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, err)
		return
	}

	bodyRequest, ok := params[validators.BodyValidatorBODY].(*struct {
		NewOfficeID        int64   `json:"new_office_id" binding:"required,OfficeID"`
		OldOfficeID        int64   `json:"old_office_id" binding:"required,OfficeID"`
		ExceptionOfficeIDs []int64 `json:"exception_office_ids" binding:"omitempty,dive,OfficeID"`
		TargetOfficeIDs    []int64 `json:"target_office_ids" binding:"omitempty,dive,OfficeID"`
	})
	if !ok {
		d.errBuilder.BindError(ctx, error_keys.Err500ConvertTypeWrong, errors.New(local_errors.UnsupportedtType))
		return
	}
	if bodyRequest == nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, errors.New(local_errors.EmptyBody))
		return
	}

	rd := d.deliverySettingsSrv.SettingsCopyByCreateService(ctx, &models.DataFromRequestSettingsCopy{
		NewOfficeID:        bodyRequest.NewOfficeID,
		OldOfficeID:        bodyRequest.OldOfficeID,
		ExceptionOfficeIDs: bodyRequest.ExceptionOfficeIDs,
		TargetOfficeIDs:    bodyRequest.TargetOfficeIDs,
		EmployeeID:         queryRequest.EmployeeID,
	})

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}

func (d deliverySettingsHandler) SettingsCopyByUpdateHandler(ctx *gin.Context, params map[string]any) {
	queryRequest, err := deliveryutils.CastQuery[models.Common](params)
	if err != nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, err)
		return
	}

	bodyRequest, ok := params[validators.BodyValidatorBODY].(*struct {
		NewOfficeID        int64   `json:"new_office_id" binding:"required,OfficeID"`
		OldOfficeID        int64   `json:"old_office_id" binding:"required,OfficeID"`
		ExceptionOfficeIDs []int64 `json:"exception_office_ids" binding:"omitempty,dive,OfficeID"`
		TargetOfficeIDs    []int64 `json:"target_office_ids" binding:"omitempty,dive,OfficeID"`
	})
	if !ok {
		d.errBuilder.BindError(ctx, error_keys.Err500ConvertTypeWrong, errors.New("unsupported type"))
		return
	}
	if bodyRequest == nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := d.deliverySettingsSrv.SettingsCopyByUpdateService(ctx, &models.DataFromRequestSettingsCopy{
		NewOfficeID:        bodyRequest.NewOfficeID,
		OldOfficeID:        bodyRequest.OldOfficeID,
		ExceptionOfficeIDs: bodyRequest.ExceptionOfficeIDs,
		TargetOfficeIDs:    bodyRequest.TargetOfficeIDs,
		EmployeeID:         queryRequest.EmployeeID,
	})

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}

func (d deliverySettingsHandler) SettingsUpdateHandler(ctx *gin.Context, params map[string]any) {
	queryRequest, err := deliveryutils.CastQuery[models.Common](params)
	if err != nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, err)
		return
	}

	bodyRequest, ok := params[validators.BodyValidatorBODY].(*struct {
		SrcOfficeID    int64   `json:"src_office_id" binding:"required,OfficeID"`
		DstOfficeArray []int64 `json:"dst_office_array" binding:"required,min=1,unique,dive,OfficeID"`
		ParkingNum     *int64  `json:"parking_num" binding:"required_without_all=RouteID ShippingWhID"`
		RouteID        *int64  `json:"route_id" binding:"required_without_all=ShippingWhID ParkingNum"`
		ShippingWhID   *int64  `json:"shipping_wh_id" binding:"required_without_all=RouteID ParkingNum"`
	})
	if !ok {
		d.errBuilder.BindError(ctx, error_keys.Err500ConvertTypeWrong, errors.New(local_errors.UnsupportedtType))
		return
	}
	if bodyRequest == nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, errors.New(local_errors.EmptyBody))
		return
	}

	rd := d.deliverySettingsSrv.SettingsUpdateService(ctx, &models.DataFromRequestSettingsUpdate{
		SrcOfficeID:    bodyRequest.SrcOfficeID,
		DstOfficeArray: bodyRequest.DstOfficeArray,
		ParkingNum:     bodyRequest.ParkingNum,
		RouteID:        bodyRequest.RouteID,
		ShippingWhID:   bodyRequest.ShippingWhID,
		EmployeeID:     queryRequest.EmployeeID,
	})

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}

func (d deliverySettingsHandler) SettingCreateHandler(ctx *gin.Context, params map[string]any) {
	queryRequest, err := deliveryutils.CastQuery[models.Common](params)
	if err != nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, err)
		return
	}

	bodyRequest, ok := params[validators.BodyValidatorBODY].(*struct {
		SrcOfficeID    int64   `json:"src_office_id" binding:"required,OfficeID"`
		DstOfficeArray []int64 `json:"dst_office_array" binding:"required,min=1,unique,dive,OfficeID"`
		ParkingNum     int64   `json:"parking_num" binding:"required,gt=0"`
		RouteGroupID   int64   `json:"routegroup_id" binding:"required,gt=0"`
		ShippingWhID   int64   `json:"shipping_wh_id" binding:"required,WhID"`
	})
	if !ok {
		d.errBuilder.BindError(ctx, error_keys.Err500ConvertTypeWrong, errors.New(local_errors.UnsupportedtType))
		return
	}
	if bodyRequest == nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, errors.New(local_errors.EmptyBody))
		return
	}

	rd := d.deliverySettingsSrv.SettingCreateService(ctx, &models.DataFromRequestSettingCreate{
		SrcOfficeID:    bodyRequest.SrcOfficeID,
		DstOfficeArray: bodyRequest.DstOfficeArray,
		ParkingNum:     bodyRequest.ParkingNum,
		RouteGroupID:   bodyRequest.RouteGroupID,
		ShippingWhID:   bodyRequest.ShippingWhID,
		EmployeeID:     queryRequest.EmployeeID,
	})

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}

func (d deliverySettingsHandler) SrcOfficesDictionaryAddHandler(ctx *gin.Context, params map[string]any) {
	queryRequest, err := deliveryutils.CastQuery[models.Common](params)
	if err != nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, err)
		return
	}

	bodyRequest, ok := params[validators.BodyValidatorBODY].(*struct {
		OfficeID int64 `json:"office_id" binding:"required,OfficeID"`
	})
	if !ok {
		d.errBuilder.BindError(ctx, error_keys.Err500ConvertTypeWrong, errors.New(local_errors.UnsupportedtType))
		return
	}
	if bodyRequest == nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, errors.New(local_errors.EmptyBody))
		return
	}

	rd := d.deliverySettingsSrv.SrcOfficesDictionaryAddService(ctx, &models.DataFromRequestSrcOfficesDictionaryAdd{
		OfficeID:   bodyRequest.OfficeID,
		EmployeeID: queryRequest.EmployeeID,
	})

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}

func (d deliverySettingsHandler) SrcOfficesDictionaryDeleteHandler(ctx *gin.Context, params map[string]any) {
	queryRequest, err := deliveryutils.CastQuery[models.Common](params)
	if err != nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, err)
		return
	}

	bodyRequest, ok := params[validators.BodyValidatorBODY].(*struct {
		OfficeID int64 `json:"office_id" binding:"required,OfficeID"`
	})
	if !ok {
		d.errBuilder.BindError(ctx, error_keys.Err500ConvertTypeWrong, errors.New(local_errors.UnsupportedtType))
		return
	}
	if bodyRequest == nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, errors.New(local_errors.EmptyBody))
		return
	}

	rd := d.deliverySettingsSrv.SrcOfficesDictionaryDeleteService(ctx, &models.DataFromRequestSrcOfficesDictionaryDelete{
		OfficeID:   bodyRequest.OfficeID,
		EmployeeID: queryRequest.EmployeeID,
	})

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}

func (d deliverySettingsHandler) SrcOfficesDictionaryGetHandler(ctx *gin.Context, _ map[string]any) {
	rd := d.deliverySettingsSrv.SrcOfficesDictionaryGetService(ctx)

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}

func (d deliverySettingsHandler) SettingsBySrcOfficeUpdateAllHandler(ctx *gin.Context, params map[string]any) {
	queryRequest, err := deliveryutils.CastQuery[models.Common](params)
	if err != nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, err)
		return
	}

	bodyRequest, ok := params[validators.BodyValidatorBODY].(*struct {
		SrcOfficeID  int64  `json:"src_office_id" binding:"required,OfficeID"`
		ParkingNum   *int64 `json:"parking_num" binding:"required_without_all=RouteID ShippingWhID"`
		RouteID      *int64 `json:"route_id" binding:"required_without_all=ShippingWhID ParkingNum"`
		ShippingWhID *int64 `json:"shipping_wh_id" binding:"required_without_all=RouteID ParkingNum"`
	})
	if !ok {
		d.errBuilder.BindError(ctx, error_keys.Err500ConvertTypeWrong, errors.New(local_errors.UnsupportedtType))
		return
	}
	if bodyRequest == nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, errors.New(local_errors.EmptyBody))
		return
	}

	rd := d.deliverySettingsSrv.SettingsBySrcOfficeUpdateAllService(ctx, &models.DataFromRequestSettingsBySrcOfficeUpdateAll{
		SrcOfficeID:  bodyRequest.SrcOfficeID,
		ParkingNum:   bodyRequest.ParkingNum,
		RouteID:      bodyRequest.RouteID,
		ShippingWhID: bodyRequest.ShippingWhID,
		EmployeeID:   queryRequest.EmployeeID,
	})

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}

func (d deliverySettingsHandler) SettingsGetAllHandler(ctx *gin.Context, params map[string]any) {
	bodyRequest, ok := params[validators.BodyValidatorBODY].(*struct {
		SrcOfficeID          *int64 `json:"src_office_id" binding:"omitempty,OfficeID"`
		DstOfficeID          *int64 `json:"dst_office_id" binding:"omitempty,OfficeID"`
		RouteID              *int64 `json:"route_id" binding:"omitempty,LteInt32"`
		WithClosedDstOffices *bool  `json:"with_closed_dst_offices" binding:"omitempty"`
	})
	if !ok {
		d.errBuilder.BindError(ctx, error_keys.Err500ConvertTypeWrong, errors.New(local_errors.UnsupportedtType))
		return
	}
	if bodyRequest == nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, errors.New(local_errors.EmptyBody))
		return
	}

	rd := d.deliverySettingsSrv.SettingsGetAllService(ctx, &models.DataFromRequestSettingsGetAll{
		SrcOfficeID:          bodyRequest.SrcOfficeID,
		DstOfficeID:          bodyRequest.DstOfficeID,
		RouteID:              bodyRequest.RouteID,
		WithClosedDstOffices: bodyRequest.WithClosedDstOffices,
	})

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}

func (d deliverySettingsHandler) SettingsDeleteHandler(ctx *gin.Context, params map[string]any) {
	queryRequest, err := deliveryutils.CastQuery[models.Common](params)
	if err != nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, err)
		return
	}

	bodyRequest, ok := params[validators.BodyValidatorBODY].(*[]struct {
		SrcOfficeID int64 `json:"src_office_id" binding:"required,OfficeID"`
		DstOfficeID int64 `json:"dst_office_id" binding:"required,OfficeID"`
	})
	if !ok {
		d.errBuilder.BindError(ctx, error_keys.Err500ConvertTypeWrong, errors.New(local_errors.UnsupportedtType))
		return
	}
	if bodyRequest == nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, errors.New(local_errors.EmptyBody))
		return
	}

	dataFromRequest := make([]models.DataFromRequestSettingsDelete, 0, len(*bodyRequest))
	for _, req := range *bodyRequest {
		dataFromRequest = append(dataFromRequest, models.DataFromRequestSettingsDelete{
			SrcOfficeID: req.SrcOfficeID,
			DstOfficeID: req.DstOfficeID,
		})
	}

	rd := d.deliverySettingsSrv.SettingsDeleteService(ctx, &dataFromRequest, queryRequest.EmployeeID)

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}

func (d deliverySettingsHandler) RoutesByRouteIdsGetHandler(ctx *gin.Context, params map[string]any) {
	bodyRequest, ok := params[validators.BodyValidatorBODY].(*struct {
		RouteIDs []int64 `json:"route_ids" binding:"required,dive,LteInt32"`
	})
	if !ok {
		d.errBuilder.BindError(ctx, error_keys.Err500ConvertTypeWrong, errors.New(local_errors.UnsupportedtType))
		return
	}
	if bodyRequest == nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, errors.New(local_errors.EmptyBody))
		return
	}

	rd := d.deliverySettingsSrv.RoutesByRouteIdsGetService(ctx, &models.DataFromRequestRoutesByRouteIdsGet{
		RouteIDs: bodyRequest.RouteIDs,
	})

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}

func (d deliverySettingsHandler) SettingsUpdateWithHiddenHandler(ctx *gin.Context, params map[string]any) {
	queryRequest, err := deliveryutils.CastQuery[models.Common](params)
	if err != nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, err)
		return
	}

	bodyRequest, ok := params[validators.BodyValidatorBODY].(*struct {
		SrcOfficeID  int64 `json:"src_office_id" binding:"required,OfficeID"`
		DstOfficeID  int64 `json:"dst_office_id" binding:"required,OfficeID"`
		ParkingNum   int64 `json:"parking_num" binding:"required,gt=0"`
		RouteID      int64 `json:"route_id" binding:"required,LteInt32"`
		ShippingWhID int64 `json:"shipping_wh_id" binding:"required,WhID"`
	})
	if !ok {
		d.errBuilder.BindError(ctx, error_keys.Err500ConvertTypeWrong, errors.New(local_errors.UnsupportedtType))
		return
	}
	if bodyRequest == nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, errors.New(local_errors.EmptyBody))
		return
	}

	rd := d.deliverySettingsSrv.SettingsUpdateWithHiddenService(ctx, &models.DataFromRequestSettingsUpdateWithHidden{
		SrcOfficeID:  bodyRequest.SrcOfficeID,
		DstOfficeID:  bodyRequest.DstOfficeID,
		ParkingNum:   bodyRequest.ParkingNum,
		RouteID:      bodyRequest.RouteID,
		ShippingWhID: bodyRequest.ShippingWhID,
		EmployeeID:   queryRequest.EmployeeID,
	})

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}

func (d deliverySettingsHandler) DstOfficeWithWrongRoutesGetHandler(ctx *gin.Context, _ map[string]any) {
	rd := d.deliverySettingsSrv.DstOfficeWithWrongRoutesGetService(ctx)

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}

func (d deliverySettingsHandler) DstOfficeWithWrongRoutesDeleteHandler(ctx *gin.Context, params map[string]any) {
	bodyRequest, ok := params[validators.BodyValidatorBODY].(*struct {
		DstOfficeID int64 `json:"dst_office_id" binding:"required,OfficeID"`
	})
	if !ok {
		d.errBuilder.BindError(ctx, error_keys.Err500ConvertTypeWrong, errors.New(local_errors.UnsupportedtType))
		return
	}
	if bodyRequest == nil {
		d.errBuilder.BindError(ctx, error_keys.ErrVldRequestBodyWrong, errors.New(local_errors.EmptyBody))
		return
	}

	rd := d.deliverySettingsSrv.DstOfficeWithWrongRoutesDeleteService(ctx, &models.DataFromRequestDstOfficeWithWrongRoutesDelete{
		DstOfficeID: bodyRequest.DstOfficeID,
	})

	deliveryutils.BindRestDataWithLogErr(ctx, rd)
}
