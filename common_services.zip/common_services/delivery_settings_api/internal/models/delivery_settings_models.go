package models

import "time"

type Common struct {
	EmployeeID int64 `json:"employee_id"`
}

// models SettingsMassUpdateRoutes
type DataFromRequestSettingsMassUpdateRoutes struct {
	SrcOfficeArray []int64
	DstOfficeArray []int64
	RouteGroupID   int64
	EmployeeID     int64
}

// models SettingsGet
type DataFromRequestSettingsGet struct {
	SrcOfficeID  *int64
	DstOfficeIDs []int64
	RouteID      *int64
}

type DataFromResponseSettingsGet struct {
	SrcOfficeID  int64      `json:"src_office_id" db:"src_office_id"`
	DstOfficeID  int64      `json:"dst_office_id" db:"dst_office_id"`
	ParkingNum   *int64     `json:"parking_num" db:"parking_num"`
	RouteID      *int64     `json:"route_id" db:"route_id"`
	ShippingWhID *int64     `json:"shipping_wh_id" db:"shipping_wh_id"`
	EmployeeID   int64      `json:"employee_id" db:"employee_id"`
	Dt           *time.Time `json:"dt" db:"dt"`
	DstTypePoint int64      `json:"dst_type_point" db:"dst_type_point"`
}

// models SettingsCopy
type DataFromRequestSettingsCopy struct {
	NewOfficeID        int64
	OldOfficeID        int64
	ExceptionOfficeIDs []int64
	TargetOfficeIDs    []int64
	EmployeeID         int64
}

// models SettingsUpdate
type DataFromRequestSettingsUpdate struct {
	SrcOfficeID    int64
	DstOfficeArray []int64
	ParkingNum     *int64
	RouteID        *int64
	ShippingWhID   *int64
	EmployeeID     int64
}

// models SettingsCreate
type DataFromRequestSettingCreate struct {
	SrcOfficeID    int64
	DstOfficeArray []int64
	ParkingNum     int64
	RouteGroupID   int64
	ShippingWhID   int64
	EmployeeID     int64
}

// models SrcOfficesDictionaryAdd
type DataFromRequestSrcOfficesDictionaryAdd struct {
	OfficeID   int64
	EmployeeID int64
}

// models SrcOfficesDictionaryAdd
type DataFromRequestSrcOfficesDictionaryDelete struct {
	OfficeID   int64
	EmployeeID int64
}

// mdels SettingsBySrcOfficeUpdateAll
type DataFromRequestSettingsBySrcOfficeUpdateAll struct {
	SrcOfficeID  int64
	ParkingNum   *int64
	RouteID      *int64
	ShippingWhID *int64
	EmployeeID   int64
}

// models SettingsGetAll
type DataFromRequestSettingsGetAll struct {
	SrcOfficeID          *int64
	DstOfficeID          *int64
	RouteID              *int64
	WithClosedDstOffices *bool
}

type DataFromResponseSettingsGetAll struct {
	SrcOfficeID  int64     `json:"src_office_id" db:"src_office_id"`
	DstOfficeID  int64     `json:"dst_office_id" db:"dst_office_id"`
	ParkingNum   *int64    `json:"parking_num" db:"parking_num"`
	RouteID      *int64    `json:"route_id" db:"route_id"`
	ShippingWhID *int64    `json:"shipping_wh_id" db:"shipping_wh_id"`
	EmployeeID   int64     `json:"employee_id" db:"employee_id"`
	Dt           time.Time `json:"dt" db:"dt"`
	DstTypePoint int64     `json:"dst_type_point" db:"dst_type_point"`
}

// models SettingsDelete
type DataFromRequestSettingsDelete struct {
	SrcOfficeID int64 `json:"src_office_id"`
	DstOfficeID int64 `json:"dst_office_id"`
}

// models RoutesByRouteIdsGet
type DataFromRequestRoutesByRouteIdsGet struct {
	RouteIDs []int64
}

// models SettingsUpdateWithHidden
type DataFromRequestSettingsUpdateWithHidden struct {
	SrcOfficeID  int64 `json:"src_office_id" db:"src_office_id"`
	DstOfficeID  int64 `json:"dst_office_id" db:"dst_office_id"`
	ParkingNum   int64 `json:"parking_num" db:"parking_num"`
	RouteID      int64 `json:"route_id" db:"route_id"`
	ShippingWhID int64 `json:"shipping_wh_id" db:"shipping_wh_id"`
	EmployeeID   int64 `json:"employee_id" db:"employee_id"`
}

type DataFromRequestDstOfficeWithWrongRoutesDelete struct {
	DstOfficeID int64
}
