package dependencies

import (
	"gitlab.wildberries.ru/wbwh/deliverysettings/backend/wh-delivery-settings.git/delivery_settings_api/internal/handlers"
	"gitlab.wildberries.ru/wbwh/deliverysettings/backend/wh-delivery-settings.git/delivery_settings_api/internal/services"
	"gitlab.wildberries.ru/wbwh/deliverysettings/backend/wh-delivery-settings.git/delivery_settings_api/internal/storage"
	rest_auto_api "gitlab.wildberries.ru/wbwh/wh-core/gocore_rest_auto_api.git/handlers"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/app"
	core_utils "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors"

	"github.com/go-playground/validator/v10"
)

type autoApiRunner interface {
	RegisterConfigurableEntity(f app.ServerConfigurationStart)
	RegisterCustomHandler(keyWord string, f rest_auto_api.CustomHandlerFunc)
}

type dependencies struct {
	errBuilder core_utils.ErrorBuilder
	validator  *validator.Validate
}

func NewDependencies(errBuilder core_utils.ErrorBuilder, validator *validator.Validate) *dependencies {
	return &dependencies{
		errBuilder: errBuilder,
		validator:  validator,
	}
}

func (d *dependencies) DependenciesInit(runner autoApiRunner) {
	pgStorage := storage.NewPgStorage(d.errBuilder)

	deliverySettingsSrv := services.NewDeliverySettingsSrv(pgStorage)

	deliverySettingsHandler := handlers.NewDeliverySettingsHandler(deliverySettingsSrv, d.errBuilder, d.validator)

	runner.RegisterCustomHandler("SettingsMassUpdateRoutes", deliverySettingsHandler.SettingsMassUpdateRoutesHandler)
	runner.RegisterCustomHandler("SettingsGet", deliverySettingsHandler.SettingsGetHandler)
	runner.RegisterCustomHandler("SettingsCopyByCreate", deliverySettingsHandler.SettingsCopyByCreateHandler)
	runner.RegisterCustomHandler("SettingsCopyByUpdate", deliverySettingsHandler.SettingsCopyByUpdateHandler)
	runner.RegisterCustomHandler("SettingsUpdate", deliverySettingsHandler.SettingsUpdateHandler)
	runner.RegisterCustomHandler("SettingCreate", deliverySettingsHandler.SettingCreateHandler)
	runner.RegisterCustomHandler("SrcOfficesDictionaryAdd", deliverySettingsHandler.SrcOfficesDictionaryAddHandler)
	runner.RegisterCustomHandler("SrcOfficesDictionaryDelete", deliverySettingsHandler.SrcOfficesDictionaryDeleteHandler)
	runner.RegisterCustomHandler("SrcOfficesDictionaryGet", deliverySettingsHandler.SrcOfficesDictionaryGetHandler)
	runner.RegisterCustomHandler("SettingsBySrcOfficeUpdateAll", deliverySettingsHandler.SettingsBySrcOfficeUpdateAllHandler)
	runner.RegisterCustomHandler("SettingsGetAll", deliverySettingsHandler.SettingsGetAllHandler)
	runner.RegisterCustomHandler("SettingsDelete", deliverySettingsHandler.SettingsDeleteHandler)
	runner.RegisterCustomHandler("RoutesByRouteIdsGet", deliverySettingsHandler.RoutesByRouteIdsGetHandler)
	runner.RegisterCustomHandler("SettingsUpdateWithHidden", deliverySettingsHandler.SettingsUpdateWithHiddenHandler)
	runner.RegisterCustomHandler("DstOfficeWithWrongRoutesGet", deliverySettingsHandler.DstOfficeWithWrongRoutesGetHandler)
	runner.RegisterCustomHandler("DstOfficeWithWrongRoutesDelete", deliverySettingsHandler.DstOfficeWithWrongRoutesDeleteHandler)
}
