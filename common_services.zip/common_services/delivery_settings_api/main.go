package main

import (
	"github.com/go-playground/validator/v10"

	"gitlab.wildberries.ru/wbwh/deliverysettings/backend/wh-delivery-settings.git/delivery_settings_api/dependencies"
	"gitlab.wildberries.ru/wbwh/deliverysettings/backend/wh-delivery-settings.git/delivery_settings_api/middleware"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_database.git/postgresql/repository/connection_control"
	rest_auto_api "gitlab.wildberries.ru/wbwh/wh-core/gocore_rest_auto_api.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs/env_config"
	core_utils "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors"
	error_keys "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors/errors_keys"
	core_logger "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/logger"
)

func main() {
	runner := rest_auto_api.NewService()
	runner.DisableJWTTokenAuth()
	runner.DisableHmacAuth()

	runner.RegisterConfigurableEntity(connection_control.InitConnections(env_config.GetCommonEnvConfigs()))

	errBuilder := core_utils.NewErrorBuilder(error_keys.NewErrorsRepository().GetErrors(), core_logger.NewLoggerMiddlewareUtils())
	valid := validator.New()

	dependencies.NewDependencies(errBuilder, valid).DependenciesInit(runner)

	runner.Run(middleware.NewMiddleware(errBuilder).Build().GetBuilder().Init()...)
}
