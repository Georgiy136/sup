package middleware

import (
	clickhouse_logger "gitlab.wildberries.ru/wbwh/deliverysettings/utils.git"
	rest_auto_api "gitlab.wildberries.ru/wbwh/wh-core/gocore_rest_auto_api.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_rest_auto_api.git/middlewares/builder"
	core_utils "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors"
	core_logger "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/logger"
)

type LocalMiddleware interface {
	Init() []rest_auto_api.CustomRunOption
}

type loggerI interface {
	LogInto(info core_logger.LogInfo)
	GetConfigName() string
}

type middleware struct {
	errBuilder        core_utils.ErrorBuilder
	middlewareBuilder builder.Middlewares
	logger            loggerI
}

func NewMiddleware(errBuilder core_utils.ErrorBuilder) *middleware {
	return &middleware{
		errBuilder:        errBuilder,
		middlewareBuilder: builder.NewMiddlewares(errBuilder),
		logger:            clickhouse_logger.NewClickhouseLogger(),
	}
}

func (m *middleware) GetBuilder() LocalMiddleware { return m.middlewareBuilder }

func (m *middleware) Build() *middleware {
	m.middlewareBuilder.Logger(m.logger, builder.WithOptionalByConfig(m.logger.GetConfigName()))
	return m
}
