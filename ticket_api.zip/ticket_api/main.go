package main

import (
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/clients"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/handlers"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/service/chat_mapper"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/services"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/storage"
	"gitlab.wildberries.ru/wbwh/support/utils.git/support_err_keys"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_database.git/postgresql/repository/connection_control"
	rest_auto_api "gitlab.wildberries.ru/wbwh/wh-core/gocore_rest_auto_api.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs/env_config"
	core_errors "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors/errors_keys"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_validators.git"

	"gitlab.wildberries.ru/wbwh/support/utils.git/body_size_limiter"
	"gitlab.wildberries.ru/wbwh/support/utils.git/middleware"

	"github.com/go-playground/validator/v10"
)

func main() {
	conf := env_config.GetCommonEnvConfigs()
	runner := rest_auto_api.NewService()

	loggerToClickhouse := middleware.NewClickhouseLoggerMiddleware()
	reqSizeLimiterOption := body_size_limiter.NewDefaultReqSizeLimiterMiddleware()

	runner.RegisterConfigurableEntity(
		connection_control.InitConnections(conf),
	)

	runner.DisableJWTTokenAuth()
	runner.DisableHmacAuth()
	runner.EnableAuthActionsCheck()

	redisClient := clients.NewRedisClient()
	resourceEmployeeAccessClient := clients.NewResourceEmployeeAccessClient()
	fileManagerClient := clients.NewSupportFileManagerApiClient()

	runner.RegisterConfigurableEntity(redisClient.Configure)
	runner.RegisterConfigurableEntity(resourceEmployeeAccessClient.Configure)
	runner.RegisterConfigurableEntity(fileManagerClient.Configure)

	chatMapper := chat_mapper.New(redisClient)
	chatMapperStreaming := chat_mapper.NewChatMapperStreaming(redisClient)

	valid := validator.New()
	gocore_validators.InitializeCustomValidatorsV10(valid)
	errBuilder := core_errors.NewErrorBuilder(errors_keys.NewErrorsRepository().GetErrors(), nil)
	errorsRepoWithSupport := errors_keys.NewErrorsRepository()
	errorsRepoWithSupport.SetErrors(support_err_keys.ErrorsRepository)
	errBuilderWithSupport := core_errors.NewErrorBuilder(errorsRepoWithSupport.GetErrors(), nil)

	pgStorage := storage.NewSupportPgStorage()
	ticketsStorage := storage.NewTicketsStorage(pgStorage)
	categoriesStorage := storage.NewCategoriesStorage(pgStorage)
	adminStorage := storage.NewAdminStorage(pgStorage)

	categoriesSrv := services.NewCategoriesSrv(categoriesStorage, errBuilder)
	categoriesHandler := handlers.NewCategoriesHandler(categoriesSrv, valid, errBuilder)
	adminSrv := services.NewAdminSrv(
		adminStorage,
		redisClient,
		resourceEmployeeAccessClient,
		ticketsStorage,
		chatMapperStreaming,
		errBuilder,
	)
	adminHandler := handlers.NewAdminHandler(adminSrv, errBuilder)
	ticketFilesSrv := services.NewTicketFilesSrv(
		redisClient,
		resourceEmployeeAccessClient,
		fileManagerClient,
		ticketsStorage,
		errBuilderWithSupport,
	)
	ticketFilesHandler := handlers.NewTicketFilesHandler(ticketFilesSrv, errBuilderWithSupport)

	ticketsHandler := handlers.NewTicketsHandler(redisClient, resourceEmployeeAccessClient, fileManagerClient, chatMapper)

	// categories
	runner.RegisterCustomHandler("AddCategory", categoriesHandler.AddCategory)
	runner.RegisterCustomHandler("GetCategoryInfoByIDV2", categoriesHandler.GetCategoryInfoByIDV2)
	runner.RegisterCustomHandler("UpdateCategoryStatus", categoriesHandler.UpdateCategoryStatus)
	runner.RegisterCustomHandler("UpdateCategory", categoriesHandler.UpdateCategory)
	runner.RegisterCustomHandler("GetCategoriesTree", categoriesHandler.GetCategoriesTree)
	runner.RegisterCustomHandler("GetCategoryStatusesInfo", categoriesHandler.GetCategoryStatusesInfo)
	runner.RegisterCustomHandler("CopyCategoryTicket", categoriesHandler.CopyCategoryTicket)
	runner.RegisterCustomHandler("CopyCategorySettings", categoriesHandler.CopyCategorySettings)
	runner.RegisterCustomHandler("MoveCategory", categoriesHandler.MoveCategory)

	// tickets
	runner.RegisterCustomHandler("CreateTicket", ticketsHandler.CreateTicket)
	runner.RegisterCustomHandler("CreateTicketV2", ticketsHandler.CreateTicketV2)
	runner.RegisterCustomHandler("CreateTicketV3", ticketsHandler.CreateTicketV3)
	runner.RegisterCustomHandler("PerformTicket", ticketsHandler.PerformTicket)
	runner.RegisterCustomHandler("PerformTicketV2", ticketsHandler.PerformTicketV2)
	runner.RegisterCustomHandler("PerformTicketV3", ticketsHandler.PerformTicketV3)
	runner.RegisterCustomHandler("ApproveTicket", ticketsHandler.ApproveTicket)
	runner.RegisterCustomHandler("ApproveTicketV2", ticketsHandler.ApproveTicketV2)
	runner.RegisterCustomHandler("ApproveTicketV3", ticketsHandler.ApproveTicketV3)
	runner.RegisterCustomHandler("BookTicket", ticketsHandler.BookTicket)
	runner.RegisterCustomHandler("BookTicketV2", ticketsHandler.BookTicketV2)
	runner.RegisterCustomHandler("UnbookTicket", ticketsHandler.UnbookTicket)
	runner.RegisterCustomHandler("UnbookTicketV2", ticketsHandler.UnbookTicketV2)
	runner.RegisterCustomHandler("RejectTicket", ticketsHandler.RejectTicket)
	runner.RegisterCustomHandler("RejectTicketV2", ticketsHandler.RejectTicketV2)
	runner.RegisterCustomHandler("RejectMyTicketOrTicketAtPerform", ticketsHandler.RejectMyTicketOrTicketAtPerform)
	runner.RegisterCustomHandler("RejectTicketAtApproveOrBook", ticketsHandler.RejectTicketAtApproveOrBook)
	runner.RegisterCustomHandler("GetTicketsCreatedByEmployee", ticketsHandler.GetTicketsCreatedByEmployee)
	runner.RegisterCustomHandler("GetTicket", ticketsHandler.GetTicket)
	runner.RegisterCustomHandler("GetTicketsForWorkV2", ticketsHandler.GetTicketsForWorkV2)
	runner.RegisterCustomHandler("GetWorkTickets", ticketsHandler.GetWorkTickets)
	runner.RegisterCustomHandler("UpdateFavouriteTickets", ticketsHandler.UpdateFavouriteTickets)
	runner.RegisterCustomHandler("TicketsFavouriteGetByEmployeeV2", ticketsHandler.TicketsFavouriteGetByEmployeeV2)
	runner.RegisterCustomHandler("TicketsFavouriteGetByEmployeeForWorkV2", ticketsHandler.TicketsFavouriteGetByEmployeeForWorkV2)
	runner.RegisterCustomHandler("GetTicketInfoByTypeAction", ticketsHandler.GetTicketInfoByTypeAction)
	runner.RegisterCustomHandler("GetTicketInfoForCenter", ticketsHandler.GetTicketInfoForCenter)
	runner.RegisterCustomHandler("GetTicketInfoForMyTickets", ticketsHandler.GetTicketInfoForMyTickets)
	runner.RegisterCustomHandler("ShareMyTicket", ticketsHandler.ShareMyTicket)
	runner.RegisterCustomHandler("ShareWorkTicket", ticketsHandler.ShareWorkTicket)
	runner.RegisterCustomHandler("GetTicketForLink", ticketsHandler.GetTicketForLink)
	runner.RegisterCustomHandler("GetMyTickets", ticketsHandler.GetMyTickets)
	runner.RegisterCustomHandler("CheckTicketAccessForSubTab", ticketsHandler.CheckTicketAccessForSubTab)
	runner.RegisterCustomHandler("GetCategoryStatusesForMyTickets", ticketsHandler.GetCategoryStatusesForMyTickets)
	runner.RegisterCustomHandler("GetCategoryStatusesForWorkTickets", ticketsHandler.GetCategoryStatusesForWorkTickets)
	runner.RegisterCustomHandler("GetTicketsByIDs", ticketsHandler.GetTicketsByIDs)
	runner.RegisterCustomHandler("DeleteTicketFromObservables", ticketsHandler.DeleteTicketFromObservables)
	runner.RegisterCustomHandler("RequestToRejectTicket", ticketsHandler.RequestToRejectTicket)
	runner.RegisterCustomHandler("UpdateTicketExt", ticketsHandler.UpdateTicketExt)
	runner.RegisterCustomHandler("GetTicketFieldInfoByCategoryStatus", ticketsHandler.GetTicketFieldInfoByCategoryStatus)
	runner.RegisterCustomHandler("ReturnTicketStatus", ticketsHandler.ReturnTicketStatus)

	// tickets files
	runner.RegisterCustomHandler("GetUploadFileLink", ticketFilesHandler.GetUploadFileLink)
	runner.RegisterCustomHandler("CompleteFileUpload", ticketFilesHandler.CompleteFileUpload)
	runner.RegisterCustomHandler("GetFileDownloadURL", ticketFilesHandler.GetFileDownloadURL)
	runner.RegisterCustomHandler("CancelFileUpload", ticketFilesHandler.CancelFileUpload)

	// admin
	runner.RegisterCustomHandler("GetTicketsByCategoryIDs", adminHandler.GetTicketsByCategoryIDs)
	runner.RegisterCustomHandler("GetCenterTickets", adminHandler.GetCenterTickets)
	runner.RegisterCustomHandler("GetCenterTicketIDs", adminHandler.GetCenterTicketIDs)
	runner.RegisterCustomHandler("GetCenterTicketByTicketIDs", adminHandler.GetCenterTicketByTicketIDs)

	runOptions := append([]rest_auto_api.CustomRunOption{reqSizeLimiterOption}, loggerToClickhouse...)

	runner.Run(runOptions...)
}
