package storage

import (
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/models"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_database.git/postgresql"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_database.git/postgresql/repository"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
)

// PgStorage is a shared DB access gateway for internal service layers.
type PgStorage interface {
	Exec(sp string, params ...any) rest_data.RestData
	ExecAndUnmarshal(sp string, dest any, params ...any) rest_data.RestData
}

type pgStorage struct {
	databaseKey string
}

func NewPgStorage(databaseKey string) PgStorage {
	return &pgStorage{databaseKey: databaseKey}
}

func NewSupportPgStorage() PgStorage {
	return NewPgStorage(models.SupportPgDatabaseKey)
}

func (p *pgStorage) Exec(sp string, params ...any) rest_data.RestData {
	pg := new(postgresql.PgSpec)
	pg.SetDatabaseKey(p.databaseKey)
	pg.SetStoredProcedureName(sp)
	pg.SetParams(params...)

	return repository.GetRestDataFromDb(pg)
}

func (p *pgStorage) ExecAndUnmarshal(sp string, dest any, params ...any) rest_data.RestData {
	pg := new(postgresql.PgSpec)
	pg.SetDatabaseKey(p.databaseKey)
	pg.SetStoredProcedureName(sp)
	pg.SetParams(params...)

	return repository.GetRestDataFromDbAndUnmarshal(pg, dest)
}
