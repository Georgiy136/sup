package storage

import "gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"

type AdminStorage interface {
	GetTicketsByCategories(categoryIDs []int64) rest_data.RestData
	GetCenterTickets(categoryIDs []int64) rest_data.RestData
	GetCenterTicketIDs(categoryIDs []int64) rest_data.RestData
	GetCenterTicketByTicketIDs(ticketIDs []int64, categoryIDs []int64) rest_data.RestData
}

type adminStorage struct {
	pg PgStorage
}

func NewAdminStorage(pg PgStorage) AdminStorage {
	return &adminStorage{pg: pg}
}

func (s *adminStorage) GetTicketsByCategories(categoryIDs []int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_getallbycategories", categoryIDs)
}

func (s *adminStorage) GetCenterTickets(categoryIDs []int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_getallforcenter", categoryIDs)
}

func (s *adminStorage) GetCenterTicketIDs(categoryIDs []int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_getticketidsforcenter", categoryIDs)
}

func (s *adminStorage) GetCenterTicketByTicketIDs(ticketIDs []int64, categoryIDs []int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_getallforcenterbyticketids", ticketIDs, categoryIDs)
}
