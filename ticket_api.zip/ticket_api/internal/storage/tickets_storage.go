package storage

import (
	"errors"
	"fmt"

	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/models"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/utils"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
)

type TicketsStorage interface {
	CreateTicket(categoryID, employeeID int64, infoForCreate []byte, scenarioOrderID *int64, ticketName string) rest_data.RestData
	CreateTicketWithReserveTicketID(categoryID, employeeID int64, infoForCreate []byte, scenarioOrderID *int64, ticketName string, ticketID int64) rest_data.RestData
	CreateTicketWithPublicCategory(categoryID, employeeID int64, infoForCreate []byte, scenarioOrderID *int64, ticketName string, isPublicCategory bool) rest_data.RestData

	ReserveTicketID() (int64, error)
	GetCategoryStatusInfoForCreate(categoryID int64) ([]models.StatusInfo, error)
	GetCategoryStatusInfo(categoryID int64, statusID string) ([]models.StatusInfo, error)
	GetTicketCommonInfo(ticketID int64) (*models.TicketCommonInfo, error)

	PerformTicket(ticketID int64, ext any, employeeID int64, scenarioOrderID *int64) rest_data.RestData
	PerformTicketV2(ticketID int64, ext string, employeeID int64, scenarioOrderID *int64) rest_data.RestData
	PerformTicketV3(ticketID int64, ext any, employeeID int64, scenarioOrderID *int64, approvedEmployeeID *int64, approvedComments *string, approvedFile []models.TicketFiles, extVersion *int64) rest_data.RestData
	RejectTicket(ticketID, employeeID int64, rejectedComments string) rest_data.RestData
	RejectTicketV2(ticketID, employeeID int64, rejectedComments string) rest_data.RestData
	RejectTicketV3(ticketID, employeeID int64, rejectedComments string, rejectedFile []models.TicketFiles, extVersion *int64) rest_data.RestData
	RejectTicketAtApproveOrBook(ticketID, employeeID int64, rejectedComments string) rest_data.RestData
	RejectTicketAtApproveOrBookV2(ticketID, employeeID int64, rejectedComments string) rest_data.RestData

	GetTicketsCreatedByEmployee(employeeID int64) rest_data.RestData
	GetTicket(ticketID, employeeID int64, tab string) rest_data.RestData
	GetTicketsForWorkV2(employeeID int64) rest_data.RestData

	ApproveTicket(ticketID int64, ext any, employeeID int64, scenarioOrderID *int64) rest_data.RestData
	ApproveTicketV2(ticketID int64, ext string, employeeID int64, scenarioOrderID *int64) rest_data.RestData
	ApproveTicketV3(ticketID int64, ext any, employeeID int64, scenarioOrderID *int64, extVersion *int64) rest_data.RestData

	BookTicket(ticketID, employeeID int64, extVersion *int64) rest_data.RestData
	BookTicketV2(ticketID, employeeID int64) rest_data.RestData
	UnbookTicket(ticketID, employeeID int64, extVersion *int64) rest_data.RestData
	UnbookTicketV2(ticketID, employeeID int64) rest_data.RestData

	UpdateFavouriteTickets(ticketID, employeeID int64, needNotification bool, changedByEmployeeID int64, isDel bool) rest_data.RestData
	GetFavouriteTicketsByEmployee(employeeID int64) rest_data.RestData
	GetFavouriteTicketsForWorkByEmployee(employeeID int64) rest_data.RestData
	GetTicketInfoForCenter(ticketID, categoryID int64) rest_data.RestData
	GetTicketInfoForMyTickets(ticketID, employeeID int64) rest_data.RestData
	ShareTicket(ticketID, recipientEmployeeID, employeeID int64, needNotification *bool) rest_data.RestData
	DeleteTicketFromObservables(ticketID, employeeID int64) rest_data.RestData
	GetWorkTickets(categoryStatusIDsJSON string, employeeID int64) rest_data.RestData
	GetTicketForLink(ticketID, employeeID int64, employeeGroups []int64) rest_data.RestData
	GetMyTickets(employeeID int64) rest_data.RestData
	RequestToRejectTicket(ticketID, employeeID int64, rejectedComments string) rest_data.RestData
	UpdateTicketExt(ticketID int64, ext string, employeeID int64) rest_data.RestData
	GetTicketFieldInfoByCategoryStatus(categoryID int64, statusID *string, dataName string) rest_data.RestData
	ReturnTicketStatus(ticketID int64, returnStatusID, returnComment string, employeeID int64) rest_data.RestData

	CheckTicketAccessForSubTab(ticketID, employeeID int64, dbTab string, categoryStatusJSON []byte) rest_data.RestData
	GetCategoryStatusesForMyTickets(employeeID int64) rest_data.RestData
	GetCategoryStatusesForWorkTickets(categoryStatusIDsJSON string) rest_data.RestData
	GetTicketsByTab(procedureName string, params ...any) rest_data.RestData
}

type ticketsStorage struct {
	pg PgStorage
}

func NewTicketsStorage(pg PgStorage) TicketsStorage {
	return &ticketsStorage{pg: pg}
}

func (s *ticketsStorage) CreateTicket(categoryID, employeeID int64, infoForCreate []byte, scenarioOrderID *int64, ticketName string) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_create", categoryID, employeeID, string(infoForCreate), scenarioOrderID, ticketName)
}

func (s *ticketsStorage) CreateTicketWithReserveTicketID(categoryID, employeeID int64, infoForCreate []byte, scenarioOrderID *int64, ticketName string, ticketID int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_create_v1", categoryID, employeeID, utils.ToJSONObjectOrDefault(infoForCreate), scenarioOrderID, ticketName, ticketID)
}

func (s *ticketsStorage) CreateTicketWithPublicCategory(categoryID, employeeID int64, infoForCreate []byte, scenarioOrderID *int64, ticketName string, isPublicCategory bool) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_create_v2", categoryID, employeeID, utils.ToJSONObjectOrDefault(infoForCreate), scenarioOrderID, ticketName, isPublicCategory)
}

func (s *ticketsStorage) ReserveTicketID() (int64, error) {
	var ticketIDFromDB models.TiketsGetIDDataFromDB
	rd := s.pg.ExecAndUnmarshal("tickets.tickets_getid", &ticketIDFromDB)
	if rd.HasError() {
		return 0, fmt.Errorf("error get ticket id from db: %w", rest_data.ToError(rd))
	}
	if rd.DataEmpty() {
		return 0, errors.New("can't create ticket id in db")
	}
	return ticketIDFromDB.TiketID, nil
}

func (s *ticketsStorage) GetCategoryStatusInfoForCreate(categoryID int64) ([]models.StatusInfo, error) {
	var categoryStatusInfo []models.StatusInfo
	rd := s.pg.ExecAndUnmarshal("tickets.categorystatus_getbystatus", &categoryStatusInfo, categoryID)
	if rd.HasError() {
		return nil, fmt.Errorf("can't get category status: %w", rest_data.ToError(rd))
	}
	return categoryStatusInfo, nil
}

func (s *ticketsStorage) GetCategoryStatusInfo(categoryID int64, statusID string) ([]models.StatusInfo, error) {
	var categoryStatusInfo []models.StatusInfo
	rd := s.pg.ExecAndUnmarshal("tickets.categorystatus_getbystatus", &categoryStatusInfo, categoryID, statusID)
	if rd.HasError() {
		return nil, fmt.Errorf("can't get category status: %w", rest_data.ToError(rd))
	}
	return categoryStatusInfo, nil
}

func (s *ticketsStorage) GetTicketCommonInfo(ticketID int64) (*models.TicketCommonInfo, error) {
	var ticketCommonInfo models.TicketCommonInfo
	rd := s.pg.ExecAndUnmarshal("tickets.tickets_getforchat", &ticketCommonInfo, ticketID)
	if rd.HasError() {
		return &ticketCommonInfo, fmt.Errorf("can't get ticket info: %w", rest_data.ToError(rd))
	}
	if rd.DataEmpty() {
		return nil, nil
	}
	return &ticketCommonInfo, nil
}

func (s *ticketsStorage) PerformTicket(ticketID int64, ext any, employeeID int64, scenarioOrderID *int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_perform", ticketID, ext, employeeID, scenarioOrderID)
}

func (s *ticketsStorage) PerformTicketV2(ticketID int64, ext string, employeeID int64, scenarioOrderID *int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_perform_v2", ticketID, ext, employeeID, scenarioOrderID)
}

func (s *ticketsStorage) PerformTicketV3(ticketID int64, ext any, employeeID int64, scenarioOrderID *int64, approvedEmployeeID *int64, approvedComments *string, approvedFile []models.TicketFiles, extVersion *int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_perform", ticketID, ext, employeeID, scenarioOrderID, approvedEmployeeID, approvedComments, approvedFile, extVersion)
}

func (s *ticketsStorage) RejectTicket(ticketID, employeeID int64, rejectedComments string) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_reject", ticketID, employeeID, rejectedComments)
}

func (s *ticketsStorage) RejectTicketV2(ticketID, employeeID int64, rejectedComments string) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_reject_v2", ticketID, employeeID, rejectedComments)
}

func (s *ticketsStorage) RejectTicketV3(ticketID, employeeID int64, rejectedComments string, rejectedFile []models.TicketFiles, extVersion *int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_reject", ticketID, employeeID, rejectedComments, nil, nil, nil, rejectedFile, extVersion)
}

func (s *ticketsStorage) RejectTicketAtApproveOrBook(ticketID, employeeID int64, rejectedComments string) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_reject_v2", ticketID, employeeID, rejectedComments)
}

func (s *ticketsStorage) RejectTicketAtApproveOrBookV2(ticketID, employeeID int64, rejectedComments string) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_reject_v2", ticketID, employeeID, rejectedComments, nil, true)
}

func (s *ticketsStorage) GetTicketsCreatedByEmployee(employeeID int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_getallbyemployee", employeeID)
}

func (s *ticketsStorage) GetTicket(ticketID, employeeID int64, tab string) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_getbyticket", ticketID, employeeID, tab)
}

func (s *ticketsStorage) GetTicketsForWorkV2(employeeID int64) rest_data.RestData {
	return s.pg.Exec("tickets.ticketsemployee_getallforwork", employeeID)
}

func (s *ticketsStorage) ApproveTicket(ticketID int64, ext any, employeeID int64, scenarioOrderID *int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_approve", ticketID, ext, employeeID, scenarioOrderID)
}

func (s *ticketsStorage) ApproveTicketV2(ticketID int64, ext string, employeeID int64, scenarioOrderID *int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_approve_v2", ticketID, ext, employeeID, scenarioOrderID)
}

func (s *ticketsStorage) ApproveTicketV3(ticketID int64, ext any, employeeID int64, scenarioOrderID *int64, extVersion *int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_approve", ticketID, ext, employeeID, scenarioOrderID, extVersion)
}

func (s *ticketsStorage) BookTicket(ticketID, employeeID int64, extVersion *int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_booking", ticketID, employeeID, extVersion)
}

func (s *ticketsStorage) BookTicketV2(ticketID, employeeID int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_booking_v2", ticketID, employeeID)
}

func (s *ticketsStorage) UnbookTicket(ticketID, employeeID int64, extVersion *int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_unbooking", ticketID, employeeID, extVersion)
}

func (s *ticketsStorage) UnbookTicketV2(ticketID, employeeID int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_unbooking_v2", ticketID, employeeID)
}

func (s *ticketsStorage) UpdateFavouriteTickets(ticketID, employeeID int64, needNotification bool, changedByEmployeeID int64, isDel bool) rest_data.RestData {
	return s.pg.Exec("tickets.ticketsfavourite_updfavourite", ticketID, employeeID, needNotification, changedByEmployeeID, isDel)
}

func (s *ticketsStorage) GetFavouriteTicketsByEmployee(employeeID int64) rest_data.RestData {
	return s.pg.Exec("tickets.ticketsfavourite_getallbyemployee", employeeID)
}

func (s *ticketsStorage) GetFavouriteTicketsForWorkByEmployee(employeeID int64) rest_data.RestData {
	return s.pg.Exec("tickets.ticketsfavourite_getallbyemployeeforwork", employeeID)
}

func (s *ticketsStorage) GetTicketInfoForCenter(ticketID, categoryID int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_getforcenter", ticketID, []int64{categoryID})
}

func (s *ticketsStorage) GetTicketInfoForMyTickets(ticketID, employeeID int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_getforown", ticketID, employeeID)
}

func (s *ticketsStorage) ShareTicket(ticketID, recipientEmployeeID, employeeID int64, needNotification *bool) rest_data.RestData {
	if needNotification == nil {
		return s.pg.Exec("tickets.ticketsfavourite_addemployee", ticketID, recipientEmployeeID, employeeID)
	}
	return s.pg.Exec("tickets.ticketsfavourite_addemployee", ticketID, recipientEmployeeID, employeeID, *needNotification)
}

func (s *ticketsStorage) DeleteTicketFromObservables(ticketID, employeeID int64) rest_data.RestData {
	return s.pg.Exec("tickets.ticketsfavourite_remotemployee", ticketID, employeeID)
}

func (s *ticketsStorage) GetWorkTickets(categoryStatusIDsJSON string, employeeID int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_getallforwork", categoryStatusIDsJSON, employeeID)
}

func (s *ticketsStorage) GetTicketForLink(ticketID, employeeID int64, employeeGroups []int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_getbyticketforlink", ticketID, employeeID, employeeGroups)
}

func (s *ticketsStorage) GetMyTickets(employeeID int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_getallforown", employeeID)
}

func (s *ticketsStorage) RequestToRejectTicket(ticketID, employeeID int64, rejectedComments string) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_prereject", ticketID, employeeID, rejectedComments)
}

func (s *ticketsStorage) UpdateTicketExt(ticketID int64, ext string, employeeID int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_ticketsextupd", ticketID, ext, employeeID)
}

func (s *ticketsStorage) GetTicketFieldInfoByCategoryStatus(categoryID int64, statusID *string, dataName string) rest_data.RestData {
	return s.pg.Exec("tickets.categorystatus_getbyext", categoryID, statusID, dataName)
}

func (s *ticketsStorage) ReturnTicketStatus(ticketID int64, returnStatusID, returnComment string, employeeID int64) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_ticketsreturnstatus", ticketID, returnStatusID, returnComment, employeeID)
}

func (s *ticketsStorage) CheckTicketAccessForSubTab(ticketID, employeeID int64, dbTab string, categoryStatusJSON []byte) rest_data.RestData {
	return s.pg.Exec("tickets.tickets_checkaccessfortab", ticketID, employeeID, dbTab, categoryStatusJSON)
}

func (s *ticketsStorage) GetCategoryStatusesForMyTickets(employeeID int64) rest_data.RestData {
	return s.pg.Exec("tickets.categorystatus_getbycreator", employeeID)
}

func (s *ticketsStorage) GetCategoryStatusesForWorkTickets(categoryStatusIDsJSON string) rest_data.RestData {
	return s.pg.Exec("tickets.categorystatus_getfornames", categoryStatusIDsJSON)
}

func (s *ticketsStorage) GetTicketsByTab(procedureName string, params ...any) rest_data.RestData {
	return s.pg.Exec(procedureName, params...)
}
