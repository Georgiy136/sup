package handlers

import (
	"errors"
	"fmt"

	"github.com/gin-gonic/gin"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/models"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/services"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_rest_auto_api.git/validators"
	utils "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git"
	core_errors "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors/errors_keys"
)

type ticketFilesHandler struct {
	srv        services.TicketFilesSrv
	errBuilder core_errors.ErrorBuilder
}

func NewTicketFilesHandler(srv services.TicketFilesSrv, errBuilder core_errors.ErrorBuilder) *ticketFilesHandler {
	return &ticketFilesHandler{
		srv:        srv,
		errBuilder: errBuilder,
	}
}

func (h *ticketFilesHandler) GetUploadFileLink(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		MimeType string `json:"mime_type" binding:"required,min=1,max=150"`
		FileSize int64  `json:"file_size" binding:"required,gt=0"`
		FileName string `json:"file_name" binding:"required,min=1,max=100"`
	})
	if !ok {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := h.srv.GetUploadFileLink(ctx, employeeID, models.GetUploadFileLinkRequest{
		MimeType: body.MimeType,
		FileSize: body.FileSize,
		FileName: body.FileName,
	})
	utils.BindRestData(ctx, rd)
}

func (h *ticketFilesHandler) CompleteFileUpload(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		UploadID int64 `json:"upload_id" binding:"required,gt=0"`
		FileID   int64 `json:"file_id" binding:"required,gt=0"`
	})
	if !ok {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := h.srv.CompleteFileUpload(ctx, employeeID, models.CompleteFileUploadRequest{
		UploadID: body.UploadID,
		FileID:   body.FileID,
	})
	utils.BindRestData(ctx, rd)
}

func (h *ticketFilesHandler) GetFileDownloadURL(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		FileID   int64 `json:"file_id" binding:"required,gt=0"`
		TicketID int64 `json:"ticket_id" binding:"required,gt=0"`
	})
	if !ok {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := h.srv.GetFileDownloadURL(ctx, employeeID, models.GetFileDownloadURLRequest{
		FileID:   body.FileID,
		TicketID: body.TicketID,
	})
	utils.BindRestData(ctx, rd)
}

func (h *ticketFilesHandler) CancelFileUpload(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		UploadID int64 `json:"upload_id" binding:"required,gt=0"`
		FileID   int64 `json:"file_id" binding:"required,gt=0"`
	})
	if !ok {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := h.srv.CancelFileUpload(ctx, employeeID, models.CancelFileUploadRequest{
		UploadID: body.UploadID,
		FileID:   body.FileID,
	})
	utils.BindRestData(ctx, rd)
}
