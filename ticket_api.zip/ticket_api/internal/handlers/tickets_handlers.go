package handlers

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"slices"

	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/access"
	custom_errors "gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/common"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/models"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/service/chat_mapper"
	ticket_services "gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/services"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/storage"
	internal_utils "gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/utils"
	ticket_validators "gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/validators"
	"gitlab.wildberries.ru/wbwh/support/utils.git/access_actions"
	"gitlab.wildberries.ru/wbwh/support/utils.git/support_err_keys"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_rest_auto_api.git/validators"
	utils "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git"
	core_errors "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors/errors_keys"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_validators.git"

	"github.com/sirupsen/logrus"

	"github.com/gin-gonic/gin"
	"github.com/go-playground/validator/v10"
	jsoniter "github.com/json-iterator/go"
)

type ticketsHandler struct {
	validator                    *validator.Validate
	errBuilder                   core_errors.ErrorBuilder
	redisClient                  ticket_services.RedisClient
	resourceEmployeeAccessClient ticket_services.ResourceEmployeeAccessClient
	supportFileManagerApiClient  ticket_services.FileManagerClient
	chatMapper                   *chat_mapper.ChatMapper
	ticketsStorage               storage.TicketsStorage
	ticketAccess                 *access.TicketAccessChecker
}

func NewTicketsHandler(
	redisClient ticket_services.RedisClient,
	resourceEmployeeAccessClient ticket_services.ResourceEmployeeAccessClient,
	supportFileManagerApiClient ticket_services.FileManagerClient,
	chatMapper *chat_mapper.ChatMapper,
) *ticketsHandler {
	valid := validator.New()
	gocore_validators.InitializeCustomValidatorsV10(valid)
	errorsRepo := errors_keys.NewErrorsRepository()
	errorsRepo.SetErrors(support_err_keys.ErrorsRepository)
	pgStorage := storage.NewSupportPgStorage()
	ticketsStorage := storage.NewTicketsStorage(pgStorage)

	return &ticketsHandler{
		validator:                    valid,
		errBuilder:                   core_errors.NewErrorBuilder(errorsRepo.GetErrors(), nil),
		redisClient:                  redisClient,
		resourceEmployeeAccessClient: resourceEmployeeAccessClient,
		supportFileManagerApiClient:  supportFileManagerApiClient,
		chatMapper:                   chatMapper,
		ticketsStorage:               ticketsStorage,
		ticketAccess:                 access.NewTicketAccessChecker(redisClient, resourceEmployeeAccessClient, ticketsStorage),
	}
}

func (t ticketsHandler) CreateTicket(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		CategoryID      int64           `json:"category_id" binding:"required,gt=0"`
		ScenarioOrderID *int64          `json:"scenario_order_id" binding:"required,gte=0"`
		TicketName      string          `json:"ticket_name" binding:"required,lte=300"`
		InfoForCreate   json.RawMessage `json:"info_for_create"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	if foundURL, hasURL := ticket_validators.FindURL(body.TicketName); hasURL {
		t.errBuilder.BindError(ctx, support_err_keys.KeyErrorTicketContainUrl, fmt.Errorf("ticket name must not contain URLs, '%s'", foundURL))
		return
	}

	rd := t.ticketsStorage.CreateTicket(
		body.CategoryID,
		employeeID,
		body.InfoForCreate,
		body.ScenarioOrderID,
		body.TicketName,
	)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) CreateTicketV2(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		CategoryID      int64           `json:"category_id" binding:"required,gt=0"`
		ScenarioOrderID *int64          `json:"scenario_order_id" binding:"required,gte=0"`
		TicketName      string          `json:"ticket_name" binding:"required,lte=300"`
		InfoForCreate   json.RawMessage `json:"info_for_create"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	if foundURL, hasURL := ticket_validators.FindURL(body.TicketName); hasURL {
		t.errBuilder.BindError(ctx, support_err_keys.KeyErrorTicketContainUrl, fmt.Errorf("ticket name must not contain URLs, '%s'", foundURL))
		return
	}

	resourceAccessPolicy, err := t.redisClient.GetResourceAccessPolicy(ctx, models.ResourceCompositeKey{
		CategoryID: body.CategoryID,
		TypeAction: "create_ticket_category",
		StatusID:   nil,
	})
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access groups for resource: %w", err))
		return
	}

	if access.IsAccessPolicyEmpty(resourceAccessPolicy) {
		utils.BindRestData(ctx, t.ticketsStorage.CreateTicketWithPublicCategory(
			body.CategoryID,
			employeeID,
			body.InfoForCreate,
			body.ScenarioOrderID,
			body.TicketName,
			true,
		))
		return
	}

	employeeAccessGroups, err := t.redisClient.GetAccessGroupsByEmployee(ctx, employeeID)
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access groups for employee: %w", err))
		return
	}

	employeeExternalActions, err := t.resourceEmployeeAccessClient.GetAccessActionsByEmployeeID(employeeID)
	if err != nil {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), fmt.Errorf("error get all access actions by employee: %w", err))
		return
	}

	if !access.HasAccessByPolicy(*resourceAccessPolicy, employeeAccessGroups, employeeExternalActions) {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldTokenAccessWrong, fmt.Errorf("no employee access for create ticket"))
	}

	utils.BindRestData(ctx, t.ticketsStorage.CreateTicketWithPublicCategory(
		body.CategoryID,
		employeeID,
		body.InfoForCreate,
		body.ScenarioOrderID,
		body.TicketName,
		false,
	))
}

func (t ticketsHandler) CreateTicketV3(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		CategoryID      int64           `json:"category_id" binding:"required,gt=0"`
		ScenarioOrderID *int64          `json:"scenario_order_id" binding:"required,gte=0"`
		TicketName      string          `json:"ticket_name" binding:"required,lte=300"`
		Files           json.RawMessage `json:"files"`
		InfoForCreate   json.RawMessage `json:"info_for_create"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	if foundURL, hasURL := ticket_validators.FindURL(body.TicketName); hasURL {
		t.errBuilder.BindError(ctx, support_err_keys.KeyErrorTicketContainUrl, fmt.Errorf("ticket name must not contain URLs, '%s'", foundURL))
		return
	}

	ticketID, err := t.ticketsStorage.ReserveTicketID()
	if err != nil {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), err)
		return
	}

	var bodyFiles map[string][]models.TicketFiles
	if len(body.Files) > 0 {
		if err := jsoniter.Unmarshal(body.Files, &bodyFiles); err != nil {
			t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, fmt.Errorf("can't unmarshal files: %w", err))
			return
		}
	}

	if len(bodyFiles) == 0 {
		utils.BindRestData(ctx, t.ticketsStorage.CreateTicketWithReserveTicketID(
			body.CategoryID,
			employeeID,
			body.InfoForCreate,
			body.ScenarioOrderID,
			body.TicketName,
			ticketID,
		))
		return
	}

	fileIDs := make([]int64, 0)
	for _, fieldFiles := range bodyFiles {
		for _, file := range fieldFiles {
			fileIDs = append(fileIDs, file.FileID)
		}
	}
	if len(fileIDs) > models.MaxFilesPerTicket {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("too many files"))
		return
	}

	fileInfoMap, err := t.getFileInfoMapByID(ctx, employeeID, fileIDs)
	if err != nil {
		if bizErr, ok := errors.AsType[*custom_errors.CustomErrorWrapper](err); ok {
			utils.BindRestData(ctx, *custom_errors.ToRestData(bizErr))
			return
		}
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), err)
		return
	}

	categoryStatusInfo, err := t.ticketsStorage.GetCategoryStatusInfoForCreate(body.CategoryID)
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, fmt.Errorf("category statuses info doesn't exist: %w", err))
		return
	}

	allowedFileTypesbyScenarioID, err := getAllowedFileTypesForScenario(categoryStatusInfo, *body.ScenarioOrderID)
	if err != nil {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), fmt.Errorf("can't get allowed file types for category %d: %w", body.CategoryID, err))
		return
	}
	if len(allowedFileTypesbyScenarioID) == 0 {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("no files allowed for ticket category"))
		return
	}

	if err := t.validatedAttachedFiles(body.InfoForCreate, bodyFiles, allowedFileTypesbyScenarioID, fileInfoMap); err != nil {
		t.errBuilder.BindError(ctx, support_err_keys.KeyErrorFileValidationFailed, err)
		return
	}

	reqAttachFilesToTicket := models.AttachFilesToTicketRequest{
		TicketID: ticketID,
		FileIDs:  fileIDs,
	}
	if err := t.supportFileManagerApiClient.AttachFilesToTicket(ctx, employeeID, reqAttachFilesToTicket); err != nil {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), fmt.Errorf("can't attach files to ticket %d: %w", ticketID, err))
		return
	}

	utils.BindRestData(ctx, t.ticketsStorage.CreateTicketWithReserveTicketID(
		body.CategoryID,
		employeeID,
		body.InfoForCreate,
		body.ScenarioOrderID,
		body.TicketName,
		ticketID,
	))
}

func getAllowedFileTypesForScenario(categoryStatusInfo []models.StatusInfo, scenarioOrderID int64) (map[string][]string, error) {
	if len(categoryStatusInfo) == 0 {
		return nil, fmt.Errorf("category ststus info is empty")
	}

	const fileFrontDatatype = "file"
	allowedFileTypesForScenario := make(map[string][]string)

	for _, v := range categoryStatusInfo[0].AddedInformationModel {
		if v.ScenarioOrderID == scenarioOrderID {
			for _, informationModel := range v.ScenarioAddedInformationModel {
				if informationModel.FrontDatatype == fileFrontDatatype {
					allowedFileTypesForScenario[informationModel.DataName] = informationModel.FileAllowedTypes
				}
			}
			break
		}
	}

	return allowedFileTypesForScenario, nil
}

func (t *ticketsHandler) getFileInfoMapByID(ctx context.Context, employeeID int64, fileIDs []int64) (map[int64]*models.GetFileInfoResponse, error) {
	fileInfoMap := make(map[int64]*models.GetFileInfoResponse, len(fileIDs))
	for _, fileID := range fileIDs {
		req := models.GetFileInfoRequest{
			FileID: fileID,
		}
		fileInfo, err := t.supportFileManagerApiClient.GetFileInfo(ctx, employeeID, req)
		if err != nil {
			return nil, fmt.Errorf("can't get file %d info: %w", fileID, err)

		}

		fileInfoMap[fileID] = fileInfo
	}

	return fileInfoMap, nil
}

func (t ticketsHandler) validatedAttachedFiles(ext json.RawMessage, bodyFilesMap map[string][]models.TicketFiles, allowedFileTypesForScenario map[string][]string, fileInfoMap map[int64]*models.GetFileInfoResponse) error {
	var extData map[string]json.RawMessage
	if err := jsoniter.Unmarshal(ext, &extData); err != nil {
		return fmt.Errorf("can't parse ext: %w", err)
	}

	for fileFieldName, bodyFiles := range bodyFilesMap {
		extValue, ok := extData[fileFieldName]
		if !ok {
			return fmt.Errorf("file field %s not found in info_for_create", fileFieldName)
		}

		var extFiles []models.TicketFiles
		if err := jsoniter.Unmarshal(extValue, &extFiles); err != nil {
			return fmt.Errorf("can't unmarshal file field %s model from info_for_create", fileFieldName)
		}

		if !slices.Equal(bodyFiles, extFiles) {
			return fmt.Errorf("file field %s model is different in info_for_create and request body", fileFieldName)
		}

		allowedFileTypesForField := internal_utils.SliceToMap(allowedFileTypesForScenario[fileFieldName])
		for _, file := range bodyFiles {
			if _, ok := allowedFileTypesForField[file.FileType]; !ok {
				return fmt.Errorf("type %s is not allowed for field %s, allowed: %v", file.FileType, fileFieldName, allowedFileTypesForField)
			}

			fileInfo, ok := fileInfoMap[file.FileID]
			if !ok {
				return fmt.Errorf("file %d doesn't exist in db", file.FileID)
			}
			if err := compareFileFields(file, fileInfo); err != nil {
				return fmt.Errorf("file %d compare field error: %w", file.FileID, err)
			}
		}
	}

	return nil
}

func compareFileFields(file models.TicketFiles, fileInfo *models.GetFileInfoResponse) error {
	switch {
	case file.FileSize != fileInfo.SizeBytes:
		return fmt.Errorf("size mismatch in file %d; expected: %d, actual: %d", file.FileID, fileInfo.SizeBytes, file.FileSize)
	case file.FileName != fileInfo.OriginalName:
		return fmt.Errorf("name mismatch in file %d; expected: %s, actual: %s", file.FileID, fileInfo.OriginalName, file.FileName)
	case file.FileType != fileInfo.MimeType:
		return fmt.Errorf("type mismatch in file %d; expected: %s, actual: %s", file.FileID, fileInfo.MimeType, file.FileType)
	}

	return nil
}

func (t ticketsHandler) PerformTicket(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID        int64           `json:"ticket_id" binding:"required,gt=0"`
		ScenarioOrderID *int64          `json:"scenario_order_id" binding:"required,gte=0"`
		Ext             json.RawMessage `json:"ext"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	var ext any
	switch body.Ext {
	case nil:
		ext = nil
	default:
		ext = string(body.Ext)
	}
	rd := t.ticketsStorage.PerformTicket(body.TicketID, ext, employeeID, body.ScenarioOrderID)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) PerformTicketV2(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID        int64           `json:"ticket_id" binding:"required,gt=0"`
		Ext             json.RawMessage `json:"ext"`
		ScenarioOrderID *int64          `json:"scenario_order_id" binding:"required,gte=0"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := t.ticketsStorage.PerformTicketV2(body.TicketID, string(body.Ext), employeeID, body.ScenarioOrderID)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) PerformTicketV3(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID        int64           `json:"ticket_id" binding:"required,gt=0"`
		ScenarioOrderID *int64          `json:"scenario_order_id" binding:"required,gte=0"`
		Ext             json.RawMessage `json:"ext"`
		ExtVersion      *string         `json:"ext_version" binding:"omitempty,uuid4"`
		Files           json.RawMessage `json:"files"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	if len(body.Files) > 0 {
		var parsedFiles map[string][]models.TicketFiles
		if err := jsoniter.Unmarshal(body.Files, &parsedFiles); err != nil {
			t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, err)
			return
		}
		if len(parsedFiles) > 0 {
			ticketCommonInfo, err := t.ticketsStorage.GetTicketCommonInfo(body.TicketID)
			if err != nil {
				t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("get ticket common info error: %w", err))
				return
			}
			if ticketCommonInfo == nil {
				t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("ticket not found"))
				return
			}

			fileIDs := make([]int64, 0, len(parsedFiles))
			for _, fieldFiles := range parsedFiles {
				for _, file := range fieldFiles {
					fileIDs = append(fileIDs, file.FileID)
				}
			}
			if len(fileIDs) > models.MaxFilesPerTicket {
				t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, fmt.Errorf("too many files, got %d, max %d", len(fileIDs), models.MaxFilesPerTicket))
				return
			}

			fileInfoMap, err := t.getFileInfoMapByID(ctx, employeeID, fileIDs)
			if err != nil {
				if bizErr, ok := errors.AsType[*custom_errors.CustomErrorWrapper](err); ok {
					utils.BindRestData(ctx, *custom_errors.ToRestData(bizErr))
					return
				}
				t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), err)
				return
			}

			categoryStatusInfo, err := t.ticketsStorage.GetCategoryStatusInfo(ticketCommonInfo.CategoryID, ticketCommonInfo.StatusID)
			if err != nil {
				t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, fmt.Errorf("category statuses info doesn't exist: %w", err))
				return
			}

			allowedFileTypesbyScenarioID, err := getAllowedFileTypesForScenario(categoryStatusInfo, *body.ScenarioOrderID)
			if err != nil {
				t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), fmt.Errorf("can't get allowed file types for category %d: %w", ticketCommonInfo.CategoryID, err))
				return
			}
			if len(allowedFileTypesbyScenarioID) == 0 {
				t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("no files allowed for ticket category"))
				return
			}

			if err := t.validatedAttachedFiles(body.Ext, parsedFiles, allowedFileTypesbyScenarioID, fileInfoMap); err != nil {
				t.errBuilder.BindError(ctx, support_err_keys.KeyErrorFileValidationFailed, err)
				return
			}

			reqAttachFilesToTicket := models.AttachFilesToTicketRequest{
				TicketID: body.TicketID,
				FileIDs:  fileIDs,
			}
			if err := t.supportFileManagerApiClient.AttachFilesToTicket(ctx, employeeID, reqAttachFilesToTicket); err != nil {
				t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), fmt.Errorf("can't attach files to ticket %d: %w", body.TicketID, err))
				return
			}
		}
	}

	var ext any
	switch body.Ext {
	case nil:
		ext = nil
	default:
		ext = string(body.Ext)
	}
	rd := t.ticketsStorage.PerformTicketV3(body.TicketID, ext, employeeID, body.ScenarioOrderID, nil, nil, nil, body.ExtVersion)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) RejectTicket(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID         int64  `json:"ticket_id" binding:"required,gt=0"`
		RejectedComments string `json:"rejected_comments" binding:"required,max=300"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	if foundURL, hasURL := ticket_validators.FindURL(body.RejectedComments); hasURL {
		t.errBuilder.BindError(ctx, support_err_keys.KeyErrorTicketContainUrl, fmt.Errorf("rejected comments must not contain URLs, '%s'", foundURL))
		return
	}

	rd := t.ticketsStorage.RejectTicket(body.TicketID, employeeID, body.RejectedComments)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) RejectTicketV2(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID         int64  `json:"ticket_id" binding:"required,gt=0"`
		RejectedComments string `json:"rejected_comments" binding:"required,max=300"`
		RejectedFile     []struct {
			FileID   int64  `json:"file_id" binding:"required,gt=0"`
			FileType string `json:"file_type" binding:"required,min=1,max=100"`
			FileSize int64  `json:"file_size" binding:"required,gt=0"`
			FileName string `json:"file_name" binding:"required,min=1,max=100"`
		} `json:"rejected_file" binding:"omitempty,gt=0"`
		ExtVersion *string `json:"ext_version" binding:"omitempty,uuid4"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	if foundURL, hasURL := ticket_validators.FindURL(body.RejectedComments); hasURL {
		t.errBuilder.BindError(ctx, support_err_keys.KeyErrorTicketContainUrl, fmt.Errorf("rejected comments must not contain URLs, '%s'", foundURL))
		return
	}

	if len(body.RejectedFile) > 0 {
		fileIDs := make([]int64, 0, len(body.RejectedFile))

		for _, file := range body.RejectedFile {
			req := models.GetFileInfoRequest{
				FileID: file.FileID,
			}

			fileInfo, err := t.supportFileManagerApiClient.GetFileInfo(ctx, employeeID, req)
			if err != nil {
				if bizErr, ok := errors.AsType[*custom_errors.CustomErrorWrapper](err); ok {
					utils.BindRestData(ctx, *custom_errors.ToRestData(bizErr))
					return
				}
				t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), fmt.Errorf("can't get file %d info: %w", file.FileID, err))
				return
			}

			f := models.TicketFiles{
				FileID:   file.FileID,
				FileType: file.FileType,
				FileSize: file.FileSize,
				FileName: file.FileName,
			}
			if err := compareFileFields(f, fileInfo); err != nil {
				t.errBuilder.BindError(ctx, support_err_keys.KeyErrorFileValidationFailed, fmt.Errorf("file %d compare field error: %w", file.FileID, err))
				return
			}

			fileIDs = append(fileIDs, file.FileID)
		}

		req := models.AttachFilesToTicketRequest{
			TicketID: body.TicketID,
			FileIDs:  fileIDs,
		}
		if err := t.supportFileManagerApiClient.AttachFilesToTicket(ctx, employeeID, req); err != nil {
			t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), fmt.Errorf("can't attach files to ticket %d: %w", body.TicketID, err))
			return
		}
	}

	rd := t.ticketsStorage.RejectTicketV3(body.TicketID, employeeID, body.RejectedComments, body.RejectedFile, body.ExtVersion)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) GetTicketsCreatedByEmployee(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	rd := t.ticketsStorage.GetTicketsCreatedByEmployee(employeeID)

	if rd.HasError() || rd.DataEmpty() {
		utils.BindRestData(ctx, rd)
		return
	}
	res, err := t.chatMapper.MapCreatedByEmployeeTicketsWithChatInfo(ctx, rd.GetData(), employeeID)
	if err != nil {
		logrus.Errorf("[GetTicketsCreatedByEmployee] MapCreatedByEmployeeTicketsWithChatInfo error: %v", err)
		utils.BindRestData(ctx, rd)
		return
	}
	rd.Data = &res

	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) GetTicket(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID int64  `json:"ticket_id" binding:"required,gt=0"`
		Tab      string `json:"tab" binding:"required,min=1,max=30"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := t.ticketsStorage.GetTicket(body.TicketID, employeeID, body.Tab)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) GetTicketsForWorkV2(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	rd := t.ticketsStorage.GetTicketsForWorkV2(employeeID)

	if rd.HasError() || rd.DataEmpty() {
		utils.BindRestData(ctx, rd)
		return
	}
	res, err := t.chatMapper.MapEmployeeWorkTicketsWithChatInfo(ctx, rd.GetData(), employeeID)
	if err != nil {
		logrus.Errorf("[GetTicketsForWorkV2] MapEmployeeWorkTicketsWithChatInfo error: %v", err)
		utils.BindRestData(ctx, rd)
		return
	}
	rd.Data = &res

	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) ApproveTicket(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID        int64           `json:"ticket_id" binding:"required,gt=0"`
		ScenarioOrderID *int64          `json:"scenario_order_id" binding:"required,gte=0"`
		Ext             json.RawMessage `json:"ext"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	var ext any
	switch body.Ext {
	case nil:
		ext = nil
	default:
		ext = string(body.Ext)
	}
	rd := t.ticketsStorage.ApproveTicket(body.TicketID, ext, employeeID, body.ScenarioOrderID)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) ApproveTicketV2(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TypeAction      string          `json:"type_action" binding:"required,min=3,max=50"`
		TicketID        int64           `json:"ticket_id" binding:"required,gt=0"`
		CategoryID      int64           `json:"category_id" binding:"required,gt=0"`
		StatusID        *string         `json:"status_id" binding:"omitempty,min=1,max=3"`
		Ext             json.RawMessage `json:"ext"`
		ScenarioOrderID *int64          `json:"scenario_order_id" binding:"required,gte=0"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	resourceAccessPolicy, err := t.redisClient.GetResourceAccessPolicy(ctx, models.ResourceCompositeKey{
		CategoryID: body.CategoryID,
		TypeAction: body.TypeAction,
		StatusID:   body.StatusID,
	})
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access policy for resource: %w", err))
		return
	}

	if access.IsAccessPolicyEmpty(resourceAccessPolicy) {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldTokenAccessWrong, fmt.Errorf(
			"no access policy found for ticket: %d, category: %d, type_action: %s, status: %v",
			body.TicketID,
			body.CategoryID,
			body.TypeAction,
			body.StatusID,
		))
		return
	}

	employeeAccessGroups, err := t.redisClient.GetAccessGroupsByEmployee(ctx, employeeID)
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access groups for employee: %w", err))
		return
	}

	employeeExternalActions, err := t.resourceEmployeeAccessClient.GetAccessActionsByEmployeeID(employeeID)
	if err != nil {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), fmt.Errorf("error get all access actions by employee: %w", err))
		return
	}

	if !access.HasAccessByPolicy(*resourceAccessPolicy, employeeAccessGroups, employeeExternalActions) {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldTokenAccessWrong, fmt.Errorf(
			"no employee access for ticket: %d, category: %d, action type: %s, status: %v",
			body.TicketID,
			body.CategoryID,
			body.TypeAction,
			body.StatusID,
		))
		return
	}

	rd := t.ticketsStorage.ApproveTicketV2(body.TicketID, string(body.Ext), employeeID, body.ScenarioOrderID)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) ApproveTicketV3(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}
	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID        int64           `json:"ticket_id" binding:"required,gt=0"`
		ScenarioOrderID *int64          `json:"scenario_order_id" binding:"required,gte=0"`
		Ext             json.RawMessage `json:"ext"`
		ExtVersion      *string         `json:"ext_version" binding:"omitempty,uuid4"`
		Files           json.RawMessage `json:"files"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	if len(body.Files) > 0 {
		var parsedFiles map[string][]models.TicketFiles
		if err := jsoniter.Unmarshal(body.Files, &parsedFiles); err != nil {
			t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, err)
			return
		}
		if len(parsedFiles) > 0 {
			ticketCommonInfo, err := t.ticketsStorage.GetTicketCommonInfo(body.TicketID)
			if err != nil {
				t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("get ticket common info error: %w", err))
				return
			}
			if ticketCommonInfo == nil {
				t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("ticket not found"))
				return
			}

			fileIDs := make([]int64, 0, len(parsedFiles))
			for _, fieldFiles := range parsedFiles {
				for _, file := range fieldFiles {
					fileIDs = append(fileIDs, file.FileID)
				}
			}
			if len(fileIDs) > models.MaxFilesPerTicket {
				t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, fmt.Errorf("too many files, got %d, max %d", len(fileIDs), models.MaxFilesPerTicket))
				return
			}

			fileInfoMap, err := t.getFileInfoMapByID(ctx, employeeID, fileIDs)
			if err != nil {
				if bizErr, ok := errors.AsType[*custom_errors.CustomErrorWrapper](err); ok {
					utils.BindRestData(ctx, *custom_errors.ToRestData(bizErr))
					return
				}
				t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), err)
				return
			}

			categoryStatusInfo, err := t.ticketsStorage.GetCategoryStatusInfo(ticketCommonInfo.CategoryID, ticketCommonInfo.StatusID)
			if err != nil {
				t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, fmt.Errorf("category statuses info doesn't exist: %w", err))
				return
			}

			allowedFileTypesbyScenarioID, err := getAllowedFileTypesForScenario(categoryStatusInfo, *body.ScenarioOrderID)
			if err != nil {
				t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), fmt.Errorf("can't get allowed file types for category %d: %w", ticketCommonInfo.CategoryID, err))
				return
			}
			if len(allowedFileTypesbyScenarioID) == 0 {
				t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("no files allowed for ticket category"))
				return
			}

			if err := t.validatedAttachedFiles(body.Ext, parsedFiles, allowedFileTypesbyScenarioID, fileInfoMap); err != nil {
				t.errBuilder.BindError(ctx, support_err_keys.KeyErrorFileValidationFailed, err)
				return
			}

			reqAttachFilesToTicket := models.AttachFilesToTicketRequest{
				TicketID: body.TicketID,
				FileIDs:  fileIDs,
			}
			if err := t.supportFileManagerApiClient.AttachFilesToTicket(ctx, employeeID, reqAttachFilesToTicket); err != nil {
				t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), fmt.Errorf("can't attach files to ticket %d: %w", body.TicketID, err))
				return
			}
		}
	}

	var ext any
	switch body.Ext {
	case nil:
		ext = nil
	default:
		ext = string(body.Ext)
	}
	rd := t.ticketsStorage.ApproveTicketV3(body.TicketID, ext, employeeID, body.ScenarioOrderID, body.ExtVersion)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) BookTicket(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID   int64   `json:"ticket_id" binding:"required,gt=0"`
		ExtVersion *string `json:"ext_version" binding:"omitempty,uuid4"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := t.ticketsStorage.BookTicket(body.TicketID, employeeID, body.ExtVersion)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) BookTicketV2(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TypeAction string  `json:"type_action" binding:"required,min=3,max=50"`
		TicketID   int64   `json:"ticket_id" binding:"required,gt=0"`
		CategoryID int64   `json:"category_id" binding:"required,gt=0"`
		StatusID   *string `json:"status_id" binding:"omitempty,min=1,max=3"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	resourceAccessPolicy, err := t.redisClient.GetResourceAccessPolicy(ctx, models.ResourceCompositeKey{
		CategoryID: body.CategoryID,
		TypeAction: body.TypeAction,
		StatusID:   body.StatusID,
	})
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access policy for resource: %w", err))
		return
	}

	if access.IsAccessPolicyEmpty(resourceAccessPolicy) {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldTokenAccessWrong, fmt.Errorf(
			"no access policy found for ticket: %d, category: %d, type_action: %s, status: %v",
			body.TicketID,
			body.CategoryID,
			body.TypeAction,
			body.StatusID,
		))
		return
	}

	employeeAccessGroups, err := t.redisClient.GetAccessGroupsByEmployee(ctx, employeeID)
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access groups for employee: %w", err))
		return
	}

	employeeExternalActions, err := t.resourceEmployeeAccessClient.GetAccessActionsByEmployeeID(employeeID)
	if err != nil {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), fmt.Errorf("error get all access actions by employee: %w", err))
		return
	}

	if !access.HasAccessByPolicy(*resourceAccessPolicy, employeeAccessGroups, employeeExternalActions) {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldTokenAccessWrong, fmt.Errorf(
			"no employee access for ticket: %d, category: %d, action type: %s, status: %v",
			body.TicketID,
			body.CategoryID,
			body.TypeAction,
			body.StatusID,
		))
		return
	}

	rd := t.ticketsStorage.BookTicketV2(body.TicketID, employeeID)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) UnbookTicket(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID   int64   `json:"ticket_id" binding:"required,gt=0"`
		ExtVersion *string `json:"ext_version" binding:"omitempty,uuid4"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := t.ticketsStorage.UnbookTicket(body.TicketID, employeeID, body.ExtVersion)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) UnbookTicketV2(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID int64 `json:"ticket_id" binding:"required,gt=0"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := t.ticketsStorage.UnbookTicketV2(body.TicketID, employeeID)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) UpdateFavouriteTickets(ctx *gin.Context, params map[string]interface{}) {
	chEmployeeID, ok := params["employee_id"].(int64)
	if !ok {
		utils.BindValidationErrorWithAbort(ctx, "can't parse ch employee id parameter")
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID         int64 `json:"ticket_id" binding:"required"`
		EmployeeID       int64 `json:"employee_id" binding:"required,EmployeeID"`
		NeedNotification *bool `json:"need_notification" binding:"required"`
		IsDel            *bool `json:"is_del" binding:"required"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := t.ticketsStorage.UpdateFavouriteTickets(
		body.TicketID,
		body.EmployeeID,
		*body.NeedNotification,
		chEmployeeID,
		*body.IsDel,
	)

	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) TicketsFavouriteGetByEmployeeV2(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	rd := t.ticketsStorage.GetFavouriteTicketsByEmployee(employeeID)

	if rd.HasError() || rd.DataEmpty() {
		utils.BindRestData(ctx, rd)
		return
	}
	res, err := t.chatMapper.MapTicketListWithChatInfo(ctx, rd.GetData(), employeeID)
	if err != nil {
		logrus.Errorf("[TicketsFavouriteGetByEmployeeV2] MapTicketListWithChatInfo error: %v", err)
		utils.BindRestData(ctx, rd)
		return
	}
	rd.Data = &res

	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) TicketsFavouriteGetByEmployeeForWorkV2(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	rd := t.ticketsStorage.GetFavouriteTicketsForWorkByEmployee(employeeID)

	if rd.HasError() || rd.DataEmpty() {
		utils.BindRestData(ctx, rd)
		return
	}
	res, err := t.chatMapper.MapTicketListWithChatInfo(ctx, rd.GetData(), employeeID)
	if err != nil {
		logrus.Errorf("[TicketsFavouriteGetByEmployeeForWorkV2] MapTicketListWithChatInfo error: %v", err)
		utils.BindRestData(ctx, rd)
		return
	}
	rd.Data = &res

	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) GetTicketInfoByTypeAction(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID   int64   `json:"ticket_id" binding:"required,gt=0"`
		CategoryID int64   `json:"category_id" binding:"required,gt=0"`
		TypeAction string  `json:"type_action" binding:"required,min=3,max=50"`
		StatusID   *string `json:"status_id" binding:"omitempty,min=1,max=3"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	resourceAccessPolicy, err := t.redisClient.GetResourceAccessPolicy(ctx, models.ResourceCompositeKey{
		CategoryID: body.CategoryID,
		TypeAction: body.TypeAction,
		StatusID:   body.StatusID,
	})
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access groups for resource: %w", err))
		return
	}

	if access.IsAccessPolicyEmpty(resourceAccessPolicy) {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldTokenAccessWrong, fmt.Errorf(
			"no actions found for ticket: %d, category: %d, action type: %s, status: %v",
			body.TicketID,
			body.CategoryID,
			body.TypeAction,
			body.StatusID,
		))
		return
	}

	employeeAccessGroups, err := t.redisClient.GetAccessGroupsByEmployee(ctx, employeeID)
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access groups for employee: %w", err))
		return
	}

	employeeExternalActions, err := t.resourceEmployeeAccessClient.GetAccessActionsByEmployeeID(employeeID)
	if err != nil {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), fmt.Errorf("error get all access actions by employee: %w", err))
		return
	}

	if !access.HasAccessByPolicy(*resourceAccessPolicy, employeeAccessGroups, employeeExternalActions) {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldTokenAccessWrong, fmt.Errorf(
			"no employee access for ticket: %d, category: %d, action type: %s, status: %v",
			body.TicketID,
			body.CategoryID,
			body.TypeAction,
			body.StatusID,
		))
		return
	}

	rd := t.ticketsStorage.GetTicketInfoForCenter(body.TicketID, body.CategoryID)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) GetTicketInfoForCenter(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID   int64   `json:"ticket_id" binding:"required,gt=0"`
		CategoryID int64   `json:"category_id" binding:"required,gt=0"`
		TypeAction string  `json:"type_action" binding:"required,min=3,max=50"`
		StatusID   *string `json:"status_id" binding:"omitempty,min=1,max=3"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	resourceAccessPolicy, err := t.redisClient.GetResourceAccessPolicy(ctx, models.ResourceCompositeKey{
		CategoryID: body.CategoryID,
		TypeAction: body.TypeAction,
		StatusID:   body.StatusID,
	})
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access groups for resource: %w", err))
		return
	}

	if access.IsAccessPolicyEmpty(resourceAccessPolicy) {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldTokenAccessWrong, fmt.Errorf(
			"no actions found for ticket: %d, category: %d, action type: %s, status: %v",
			body.TicketID,
			body.CategoryID,
			body.TypeAction,
			body.StatusID,
		))
		return
	}

	employeeAccessGroups, err := t.redisClient.GetAccessGroupsByEmployee(ctx, employeeID)
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access groups for employee: %w", err))
		return
	}

	employeeExternalActions, err := t.resourceEmployeeAccessClient.GetAccessActionsByEmployeeID(employeeID)
	if err != nil {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), fmt.Errorf("error get all access actions by employee: %w", err))
		return
	}

	if !access.HasAccessByPolicy(*resourceAccessPolicy, employeeAccessGroups, employeeExternalActions) {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldTokenAccessWrong, fmt.Errorf(
			"no employee access for ticket: %d, category: %d, action type: %s, status: %v",
			body.TicketID,
			body.CategoryID,
			body.TypeAction,
			body.StatusID,
		))
		return
	}

	rd := t.ticketsStorage.GetTicketInfoForCenter(body.TicketID, body.CategoryID)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) GetTicketInfoForMyTickets(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID int64 `json:"ticket_id" binding:"required,gt=0"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := t.ticketsStorage.GetTicketInfoForMyTickets(body.TicketID, employeeID)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) ShareMyTicket(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		RecipientEmployeeID int64 `json:"recipient_employee_id" binding:"required,EmployeeID"`
		TicketID            int64 `json:"ticket_id" binding:"required,gt=0"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := t.ticketsStorage.ShareTicket(body.TicketID, body.RecipientEmployeeID, employeeID, nil)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) ShareWorkTicket(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		RecipientEmployeeID int64   `json:"recipient_employee_id" binding:"required,EmployeeID"`
		TypeAction          string  `json:"type_action" binding:"required,oneof=status_approve_category status_perform_category"`
		TicketID            int64   `json:"ticket_id" binding:"required,gt=0"`
		CategoryID          int64   `json:"category_id" binding:"required,gt=0"`
		StatusID            *string `json:"status_id" binding:"omitempty,min=1,max=3"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	resourceAccessPolicy, err := t.redisClient.GetResourceAccessPolicy(ctx, models.ResourceCompositeKey{
		CategoryID: body.CategoryID,
		TypeAction: body.TypeAction,
		StatusID:   body.StatusID,
	})
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access policy for resource: %w", err))
		return
	}

	if access.IsAccessPolicyEmpty(resourceAccessPolicy) {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldTokenAccessWrong, fmt.Errorf(
			"no access policy found for ticket: %d, category: %d, type_action: %s, status: %v",
			body.TicketID,
			body.CategoryID,
			body.TypeAction,
			body.StatusID,
		))
		return
	}

	employeeAccessGroups, err := t.redisClient.GetAccessGroupsByEmployee(ctx, employeeID)
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access groups for employee: %w", err))
		return
	}

	employeeExternalActions, err := t.resourceEmployeeAccessClient.GetAccessActionsByEmployeeID(employeeID)
	if err != nil {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), fmt.Errorf("error get all access actions by employee: %w", err))
		return
	}

	if !access.HasAccessByPolicy(*resourceAccessPolicy, employeeAccessGroups, employeeExternalActions) {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldTokenAccessWrong, fmt.Errorf(
			"no employee access for ticket: %d, category: %d, action type: %s, status: %v",
			body.TicketID,
			body.CategoryID,
			body.TypeAction,
			body.StatusID,
		))
		return
	}

	needNotification := true
	rd := t.ticketsStorage.ShareTicket(body.TicketID, body.RecipientEmployeeID, employeeID, &needNotification)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) DeleteTicketFromObservables(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID int64 `json:"ticket_id" binding:"required,gt=0"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := t.ticketsStorage.DeleteTicketFromObservables(body.TicketID, employeeID)

	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) GetWorkTickets(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	categoryStatusAccess, err := t.ticketAccess.GetEmployeeCategoryStatusAccess(ctx.Request.Context(), employeeID, access_actions.TypeActionStatusApproveCategory, access_actions.TypeActionStatusPerformCategory)
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, err)
		return
	}
	if len(categoryStatusAccess) == 0 {
		utils.BindNoContent(ctx)
		return
	}

	categoryStatusIDsJSON, err := jsoniter.Marshal(categoryStatusAccess)
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500MarshalWrong, fmt.Errorf("can't marshal category status access: %w", err))
		return
	}

	rd := t.ticketsStorage.GetWorkTickets(string(categoryStatusIDsJSON), employeeID)

	if rd.HasError() || rd.DataEmpty() {
		utils.BindRestData(ctx, rd)
		return
	}
	res, err := t.chatMapper.MapTicketListWithChatInfo(ctx, rd.GetData(), employeeID)
	if err != nil {
		logrus.Errorf("[GetWorkTickets] MapTicketListWithChatInfo error: %v", err)
		utils.BindRestData(ctx, rd)
		return
	}
	rd.Data = &res

	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) GetTicketForLink(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID int64 `json:"ticket_id" binding:"required,gt=0"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	hasAccess, err := t.ticketAccess.HasEmployeeTicketAccess(ctx, employeeID, body.TicketID,
		access_actions.TypeActionCreateTicketCategory,
		access_actions.TypeActionViewTicketCategory,
		access_actions.TypeActionStatusApproveCategory,
		access_actions.TypeActionStatusPerformCategory,
	)
	if err != nil {
		if errors.Is(err, custom_errors.ErrTicketNotFound) {
			t.errBuilder.BindError(ctx, support_err_keys.KeyErrorTicketNotFound, err)
			return
		}
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, fmt.Errorf("check ticket access error: %w", err))
		return
	}
	if !hasAccess {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldTokenAccessWrong, errors.New("no access to get info ticket"))
		return
	}

	employeeGroups, err := t.redisClient.GetAccessGroupsByEmployee(ctx, employeeID)
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access groups for employee: %w", err))
		return
	}

	utils.BindRestData(ctx, t.ticketsStorage.GetTicketForLink(body.TicketID, employeeID, employeeGroups))
}

func (t ticketsHandler) GetMyTickets(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	rd := t.ticketsStorage.GetMyTickets(employeeID)

	if rd.HasError() || rd.DataEmpty() {
		utils.BindRestData(ctx, rd)
		return
	}
	res, err := t.chatMapper.MapOwnTicketsWithChatInfo(ctx, rd.GetData(), employeeID)
	if err != nil {
		logrus.Errorf("[GetMyTickets] MapOwnTicketsWithChatInfo error: %v", err)
		utils.BindRestData(ctx, rd)
		return
	}
	rd.Data = &res

	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) RejectMyTicketOrTicketAtPerform(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID         int64  `json:"ticket_id" binding:"required,gt=0"`
		RejectedComments string `json:"rejected_comments" binding:"required,max=400"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	if foundURL, hasURL := ticket_validators.FindURL(body.RejectedComments); hasURL {
		t.errBuilder.BindError(ctx, support_err_keys.KeyErrorTicketContainUrl, fmt.Errorf("rejected comments must not contain URLs, '%s'", foundURL))
		return
	}

	rd := t.ticketsStorage.RejectTicketV2(body.TicketID, employeeID, body.RejectedComments)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) RejectTicketAtApproveOrBook(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TypeAction       string  `json:"type_action" binding:"required,oneof=status_approve_category status_perform_category"`
		TicketID         int64   `json:"ticket_id" binding:"required,gt=0"`
		CategoryID       int64   `json:"category_id" binding:"required,gt=0"`
		StatusID         *string `json:"status_id" binding:"omitempty,min=1,max=3"`
		RejectedComments string  `json:"rejected_comments" binding:"required,max=400"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	if foundURL, hasURL := ticket_validators.FindURL(body.RejectedComments); hasURL {
		t.errBuilder.BindError(ctx, support_err_keys.KeyErrorTicketContainUrl, fmt.Errorf("rejected comments must not contain URLs, '%s'", foundURL))
		return
	}

	resourceAccessPolicy, err := t.redisClient.GetResourceAccessPolicy(ctx, models.ResourceCompositeKey{
		CategoryID: body.CategoryID,
		TypeAction: body.TypeAction,
		StatusID:   body.StatusID,
	})
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access policy for resource: %w", err))
		return
	}

	if access.IsAccessPolicyEmpty(resourceAccessPolicy) {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldTokenAccessWrong, fmt.Errorf(
			"no access policy found for ticket: %d, category: %d, type_action: %s, status: %v",
			body.TicketID,
			body.CategoryID,
			body.TypeAction,
			body.StatusID,
		))
		return
	}

	employeeAccessGroups, err := t.redisClient.GetAccessGroupsByEmployee(ctx, employeeID)
	if err != nil {
		t.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access groups for employee: %w", err))
		return
	}

	employeeExternalActions, err := t.resourceEmployeeAccessClient.GetAccessActionsByEmployeeID(employeeID)
	if err != nil {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), fmt.Errorf("error get all access actions by employee: %w", err))
		return
	}

	if !access.HasAccessByPolicy(*resourceAccessPolicy, employeeAccessGroups, employeeExternalActions) {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldTokenAccessWrong, fmt.Errorf(
			"employee has no access for ticket: %d, category: %d, type_action: %s, status: %v",
			body.TicketID,
			body.CategoryID,
			body.TypeAction,
			body.StatusID,
		))
		return
	}

	rd := t.ticketsStorage.RejectTicketAtApproveOrBookV2(body.TicketID, employeeID, body.RejectedComments)
	utils.BindRestData(ctx, rd)
}

func (t ticketsHandler) RequestToRejectTicket(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID         int64  `json:"ticket_id" binding:"required,gt=0"`
		RejectedComments string `json:"rejected_comments" binding:"required,max=400"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	if foundURL, hasURL := ticket_validators.FindURL(body.RejectedComments); hasURL {
		t.errBuilder.BindError(ctx, support_err_keys.KeyErrorTicketContainUrl, fmt.Errorf("rejected comments must not contain URLs, '%s'", foundURL))
		return
	}

	rd := t.ticketsStorage.RequestToRejectTicket(body.TicketID, employeeID, body.RejectedComments)
	utils.BindRestData(ctx, rd)
}

func (t *ticketsHandler) UpdateTicketExt(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID int64           `json:"ticket_id" binding:"required,gt=0"`
		Ext      json.RawMessage `json:"ext"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := t.ticketsStorage.UpdateTicketExt(body.TicketID, string(body.Ext), employeeID)
	utils.BindRestData(ctx, rd)
}

func (t *ticketsHandler) GetTicketFieldInfoByCategoryStatus(ctx *gin.Context, params map[string]interface{}) {
	body, ok := params[validators.BodyValidatorBODY].(*struct {
		CategoryID int64   `json:"category_id" binding:"required,gt=0"`
		StatusID   *string `json:"status_id" binding:"omitempty,min=1,max=3"`
		DataName   string  `json:"data_name" binding:"required,lte=30"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := t.ticketsStorage.GetTicketFieldInfoByCategoryStatus(body.CategoryID, body.StatusID, body.DataName)
	utils.BindRestData(ctx, rd)
}

func (t *ticketsHandler) ReturnTicketStatus(ctx *gin.Context, params map[string]interface{}) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		t.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketID       int64  `json:"ticket_id" binding:"required,gt=0"`
		ReturnStatusID string `json:"return_status_id" binding:"required,min=1,max=3"`
		ReturnComment  string `json:"return_comment" binding:"required,max=500"`
	})
	if !ok {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		t.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := t.ticketsStorage.ReturnTicketStatus(body.TicketID, body.ReturnStatusID, body.ReturnComment, employeeID)
	utils.BindRestData(ctx, rd)
}
