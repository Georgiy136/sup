package handlers

import (
	"encoding/json"
	"errors"
	"fmt"

	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/models"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/services"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_rest_auto_api.git/validators"
	utils "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git"
	core_errors "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors/errors_keys"

	"github.com/gin-gonic/gin"
	"github.com/go-playground/validator/v10"
	jsoniter "github.com/json-iterator/go"
)

type categoriesHandler struct {
	validator  *validator.Validate
	srv        services.CategoriesSrv
	errBuilder core_errors.ErrorBuilder
}

func NewCategoriesHandler(srv services.CategoriesSrv, valid *validator.Validate, errBuilder core_errors.ErrorBuilder) *categoriesHandler {
	return &categoriesHandler{
		validator:  valid,
		srv:        srv,
		errBuilder: errBuilder,
	}
}

func (h *categoriesHandler) GetCategoryInfoByIDV2(ctx *gin.Context, params map[string]any) {
	body, ok := params[validators.BodyValidatorBODY].(*struct {
		CategoryID int64   `json:"category_id" binding:"required,gt=0"`
		StatusID   *string `json:"status_id" binding:"omitempty,gt=0,max=3"`
	})
	if !ok {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := h.srv.GetCategoryInfoByID(models.DataFromRequestGetCategoryInfoByID{
		CategoryID: body.CategoryID,
		StatusID:   body.StatusID,
	})
	utils.BindRestData(ctx, rd)
}

func (h *categoriesHandler) AddCategory(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	rawBody, ok := params[validators.RawBODY].([]byte)
	if !ok {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if len(rawBody) == 0 {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	var body models.AddCategoryRequest
	if err := jsoniter.Unmarshal(rawBody, &body); err != nil {
		h.errBuilder.BindError(ctx, errors_keys.Err500UnmarshalWrong, fmt.Errorf("can't unmarshal body: %w", err))
		return
	}
	if err := h.validator.Struct(body); err != nil {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, fmt.Errorf("validate body error: %w", err))
		return
	}

	rd := h.srv.AddCategory(body, employeeID)
	utils.BindRestData(ctx, rd)
}

func (h *categoriesHandler) UpdateCategoryStatus(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		CategoryID int64 `json:"category_id" binding:"required"`
		StatusInfo []struct {
			IsMain                *bool           `json:"is_main" binding:"required"`
			StatusID              string          `json:"status_id" binding:"required"`
			ConstructorOrderID    int64           `json:"constructor_order_id" binding:"required"`
			ApproveGroupID        *int64          `json:"approve_group_id" binding:"omitempty"`
			PerformGroupID        *int64          `json:"perform_group_id" binding:"omitempty"`
			HasPrereject          *bool           `json:"has_prereject" binding:"required"`
			InformationModel      json.RawMessage `json:"information_model" binding:"omitempty"`
			ApproveGroupName      *string         `json:"approve_group_name" binding:"omitempty,lte=100"`
			PerformGroupName      *string         `json:"perform_group_name" binding:"omitempty,lte=100"`
			StatusDescription     string          `json:"status_description" binding:"required,lte=100"`
			AutoAPI               *string         `json:"autoapi"`
			ScenarioLabel         *string         `json:"scenario_label" binding:"omitempty,lte=100"`
			WarningDescription    *string         `json:"warning_description" binding:"omitempty,lte=100"`
			InfoDescription       *string         `json:"info_description" binding:"omitempty,lte=100"`
			IsBlockedReject       *bool           `json:"is_blocked_reject" binding:"omitempty"`
			ReturnStatusIDs       []string        `json:"return_status_ids" binding:"omitempty,dive,min=1,max=3"`
			IsBlockedStatus       *bool           `json:"is_blocked_status" binding:"omitempty"`
			AddedInformationModel []struct {
				ScenarioOrderID               *int64 `json:"scenario_order_id" binding:"required,gte=0"`
				ScenarioName                  string `json:"scenario_name" binding:"required,lte=100"`
				NextStatusID                  string `json:"next_status_id" binding:"required,lte=3"`
				ScenarioAddedInformationModel []struct {
					DataName           string          `json:"data_name" binding:"required,lte=30"`
					OrderID            int64           `json:"order_id" binding:"required"`
					DataType           string          `json:"data_type" binding:"required,lte=15"`
					FrontDataName      string          `json:"front_data_name" binding:"required,lte=100"`
					IsRequired         *bool           `json:"is_required" binding:"required"`
					FrontModel         json.RawMessage `json:"front_model" binding:"required"`
					IsHiddenForCreator *bool           `json:"is_hidden_for_creator" binding:"required"`
				} `json:"scenario_added_information_model" binding:"required"`
			} `json:"added_information_model" binding:"omitempty"`
		} `json:"status_info" binding:"required"`
	})
	if !ok {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	statusInfo := make([]models.CategoryStatusInfoItem, 0, len(body.StatusInfo))
	for _, item := range body.StatusInfo {
		addedInfo := make([]models.CategoryAddedInformationItem, 0, len(item.AddedInformationModel))
		for _, added := range item.AddedInformationModel {
			fields := make([]models.CategoryScenarioAddedInformationField, 0, len(added.ScenarioAddedInformationModel))
			for _, f := range added.ScenarioAddedInformationModel {
				fields = append(fields, models.CategoryScenarioAddedInformationField{
					DataName:           f.DataName,
					OrderID:            f.OrderID,
					DataType:           f.DataType,
					FrontDataName:      f.FrontDataName,
					IsRequired:         f.IsRequired,
					FrontModel:         f.FrontModel,
					IsHiddenForCreator: f.IsHiddenForCreator,
				})
			}
			addedInfo = append(addedInfo, models.CategoryAddedInformationItem{
				ScenarioOrderID:               added.ScenarioOrderID,
				ScenarioName:                  added.ScenarioName,
				NextStatusID:                  added.NextStatusID,
				ScenarioAddedInformationModel: fields,
			})
		}
		statusInfo = append(statusInfo, models.CategoryStatusInfoItem{
			IsMain:                item.IsMain,
			StatusID:              item.StatusID,
			ConstructorOrderID:    item.ConstructorOrderID,
			ApproveGroupID:        item.ApproveGroupID,
			PerformGroupID:        item.PerformGroupID,
			HasPrereject:          item.HasPrereject,
			InformationModel:      item.InformationModel,
			ApproveGroupName:      item.ApproveGroupName,
			PerformGroupName:      item.PerformGroupName,
			StatusDescription:     item.StatusDescription,
			AutoAPI:               item.AutoAPI,
			ScenarioLabel:         item.ScenarioLabel,
			WarningDescription:    item.WarningDescription,
			InfoDescription:       item.InfoDescription,
			IsBlockedReject:       item.IsBlockedReject,
			ReturnStatusIDs:       item.ReturnStatusIDs,
			IsBlockedStatus:       item.IsBlockedStatus,
			AddedInformationModel: addedInfo,
		})
	}

	rd := h.srv.UpdateCategoryStatus(models.DataFromRequestUpdateCategoryStatus{
		CategoryID: body.CategoryID,
		StatusInfo: statusInfo,
		EmployeeID: employeeID,
	})
	utils.BindRestData(ctx, rd)
}

func (h *categoriesHandler) GetCategoriesTree(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	rd := h.srv.GetCategoriesTree(employeeID)
	utils.BindRestData(ctx, rd)
}

func (h *categoriesHandler) GetCategoryStatusesInfo(ctx *gin.Context, params map[string]any) {
	body, ok := params[validators.BodyValidatorBODY].(*struct {
		CategoryID int64 `json:"category_id" binding:"required,gt=0"`
	})
	if !ok {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := h.srv.GetCategoryStatusesInfo(models.DataFromRequestGetCategoryStatusesInfo{CategoryID: body.CategoryID})
	utils.BindRestData(ctx, rd)
}

func (h *categoriesHandler) UpdateCategory(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	rawBody, ok := params[validators.RawBODY].([]byte)
	if !ok {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if len(rawBody) == 0 {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	var body models.UpdateCategoryRequest
	if err := jsoniter.Unmarshal(rawBody, &body); err != nil {
		h.errBuilder.BindError(ctx, errors_keys.Err500UnmarshalWrong, fmt.Errorf("can't unmarshal body: %w", err))
		return
	}
	if err := h.validator.Struct(body); err != nil {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, fmt.Errorf("validate body error: %w", err))
		return
	}

	rd := h.srv.UpdateCategory(body, employeeID)
	utils.BindRestData(ctx, rd)
}

func (h *categoriesHandler) CopyCategoryTicket(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		CategoryID       int64 `json:"category_id" binding:"required"`
		ParentCategoryID int64 `json:"parent_category_id" binding:"required"`
	})
	if !ok {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := h.srv.CopyCategoryTicket(models.DataFromRequestCopyCategoryTicket{
		CategoryID:       body.CategoryID,
		ParentCategoryID: body.ParentCategoryID,
		EmployeeID:       employeeID,
	})
	utils.BindRestData(ctx, rd)
}

func (h *categoriesHandler) CopyCategorySettings(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		SourceCategoryID int64 `json:"source_category_id" binding:"required,gt=0"`
		TargetCategoryID int64 `json:"target_category_id" binding:"required,gt=0"`
	})
	if !ok {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := h.srv.CopyCategorySettings(models.DataFromRequestCopyCategorySettings{
		SourceCategoryID: body.SourceCategoryID,
		TargetCategoryID: body.TargetCategoryID,
		EmployeeID:       employeeID,
	})
	utils.BindRestData(ctx, rd)
}

func (h *categoriesHandler) MoveCategory(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		CategoryID       int64 `json:"category_id" binding:"required,gt=0"`
		ParentCategoryID int64 `json:"parent_category_id" binding:"required,gt=0"`
	})
	if !ok {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := h.srv.MoveCategory(models.DataFromRequestMoveCategory{
		CategoryID:       body.CategoryID,
		ParentCategoryID: body.ParentCategoryID,
		EmployeeID:       employeeID,
	})
	utils.BindRestData(ctx, rd)
}
