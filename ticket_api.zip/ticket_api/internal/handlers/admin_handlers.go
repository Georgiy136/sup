package handlers

import (
	"errors"
	"fmt"

	"github.com/gin-gonic/gin"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/models"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/services"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_rest_auto_api.git/validators"
	utils "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git"
	core_errors "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors/errors_keys"
)

type adminHandler struct {
	srv        services.AdminSrv
	errBuilder core_errors.ErrorBuilder
}

func NewAdminHandler(srv services.AdminSrv, errBuilder core_errors.ErrorBuilder) *adminHandler {
	return &adminHandler{
		srv:        srv,
		errBuilder: errBuilder,
	}
}

func (h *adminHandler) GetTicketsByCategoryIDs(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TypeAction  string  `json:"type_action" binding:"required"`
		CategoryIDs []int64 `json:"category_ids" binding:"required,gt=0"`
	})
	if !ok {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := h.srv.GetTicketsByCategoryIDs(ctx, employeeID, models.GetTicketsByCategoryIDsRequest{
		TypeAction:  body.TypeAction,
		CategoryIDs: body.CategoryIDs,
	})
	utils.BindRestData(ctx, rd)
}

func (h *adminHandler) GetCenterTickets(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TypeAction  string  `json:"type_action" binding:"required"`
		CategoryIDs []int64 `json:"category_ids" binding:"required,min=1,max=5"`
	})
	if !ok {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := h.srv.GetCenterTickets(ctx, employeeID, models.GetCenterTicketsRequest{
		TypeAction:  body.TypeAction,
		CategoryIDs: body.CategoryIDs,
	})
	utils.BindRestData(ctx, rd)
}

func (h *adminHandler) GetViewTickets(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	rd := h.srv.GetViewTickets(ctx, employeeID)
	utils.BindRestData(ctx, rd)
}

func (h *adminHandler) GetCenterTicketIDs(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	rd := h.srv.GetCenterTicketIDs(ctx, employeeID)
	utils.BindRestData(ctx, rd)
}

func (h *adminHandler) GetCenterTicketByTicketIDs(ctx *gin.Context, params map[string]any) {
	employeeID, ok := params["employee_id"].(int64)
	if !ok {
		h.errBuilder.BindError(ctx, core_errors.ErrorKey(errors_keys.ErrorKeyValidation), fmt.Errorf("can't parse employeeID parameter"))
		return
	}

	body, ok := params[validators.BodyValidatorBODY].(*struct {
		TicketIDs []int64 `json:"ticket_ids" binding:"required,gt=0,lte=100,dive,gt=0"`
	})
	if !ok {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		h.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	rd := h.srv.GetCenterTicketByTicketIDs(ctx, employeeID, models.GetCenterTicketByTicketIDsRequest{
		TicketIDs: body.TicketIDs,
	})
	utils.BindRestData(ctx, rd)
}
