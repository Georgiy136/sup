package models

import "encoding/json"

type DataFromRequestGetCategoryInfoByID struct {
	CategoryID int64
	StatusID   *string
}

type DataFromRequestUpdateCategoryStatus struct {
	CategoryID int64
	StatusInfo []CategoryStatusInfoItem
	EmployeeID int64
}

type CategoryStatusInfoItem struct {
	IsMain                *bool                          `json:"is_main" binding:"required"`
	StatusID              string                         `json:"status_id" binding:"required"`
	ConstructorOrderID    int64                          `json:"constructor_order_id" binding:"required"`
	ApproveGroupID        *int64                         `json:"approve_group_id" binding:"omitempty"`
	PerformGroupID        *int64                         `json:"perform_group_id" binding:"omitempty"`
	HasPrereject          *bool                          `json:"has_prereject" binding:"required"`
	InformationModel      json.RawMessage                `json:"information_model" binding:"omitempty"`
	ApproveGroupName      *string                        `json:"approve_group_name" binding:"omitempty,lte=100"`
	PerformGroupName      *string                        `json:"perform_group_name" binding:"omitempty,lte=100"`
	StatusDescription     string                         `json:"status_description" binding:"required,lte=100"`
	AutoAPI               *string                        `json:"autoapi"`
	ScenarioLabel         *string                        `json:"scenario_label" binding:"omitempty,lte=100"`
	WarningDescription    *string                        `json:"warning_description" binding:"omitempty,lte=100"`
	InfoDescription       *string                        `json:"info_description" binding:"omitempty,lte=100"`
	IsBlockedReject       *bool                          `json:"is_blocked_reject" binding:"omitempty"`
	ReturnStatusIDs       []string                       `json:"return_status_ids" binding:"omitempty,dive,min=1,max=3"`
	IsBlockedStatus       *bool                          `json:"is_blocked_status" binding:"omitempty"`
	AddedInformationModel []CategoryAddedInformationItem `json:"added_information_model" binding:"omitempty"`
}

type CategoryAddedInformationItem struct {
	ScenarioOrderID               *int64                                  `json:"scenario_order_id" binding:"required,gte=0"`
	ScenarioName                  string                                  `json:"scenario_name" binding:"required,lte=100"`
	NextStatusID                  string                                  `json:"next_status_id" binding:"required,lte=3"`
	ScenarioAddedInformationModel []CategoryScenarioAddedInformationField `json:"scenario_added_information_model" binding:"required"`
}

type CategoryScenarioAddedInformationField struct {
	DataName           string          `json:"data_name" binding:"required,lte=30"`
	OrderID            int64           `json:"order_id" binding:"required"`
	DataType           string          `json:"data_type" binding:"required,lte=15"`
	FrontDataName      string          `json:"front_data_name" binding:"required,lte=100"`
	IsRequired         *bool           `json:"is_required" binding:"required"`
	FrontModel         json.RawMessage `json:"front_model" binding:"required"`
	IsHiddenForCreator *bool           `json:"is_hidden_for_creator" binding:"required"`
}

type DataFromRequestGetCategoryStatusesInfo struct {
	CategoryID int64
}

type DataFromRequestCopyCategoryTicket struct {
	CategoryID       int64
	ParentCategoryID int64
	EmployeeID       int64
}

type DataFromRequestCopyCategorySettings struct {
	SourceCategoryID int64
	TargetCategoryID int64
	EmployeeID       int64
}

type DataFromRequestMoveCategory struct {
	CategoryID       int64
	ParentCategoryID int64
	EmployeeID       int64
}
