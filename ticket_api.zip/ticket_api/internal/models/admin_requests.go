package models

type GetTicketsByCategoryIDsRequest struct {
	TypeAction  string
	CategoryIDs []int64
}

type GetCenterTicketsRequest struct {
	TypeAction  string
	CategoryIDs []int64
}

type GetCenterTicketByTicketIDsRequest struct {
	TicketIDs []int64
}
