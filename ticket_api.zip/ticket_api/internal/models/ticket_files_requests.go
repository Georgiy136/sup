package models

type GetUploadFileLinkRequest struct {
	MimeType string
	FileSize int64
	FileName string
}

type CompleteFileUploadRequest struct {
	UploadID int64
	FileID   int64
}

type GetFileDownloadURLRequest struct {
	FileID   int64
	TicketID int64
}

type CancelFileUploadRequest struct {
	UploadID int64
	FileID   int64
}
