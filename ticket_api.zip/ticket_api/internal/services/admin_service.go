package services

import (
	"context"
	"net/http"

	"github.com/sirupsen/logrus"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/access"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/models"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/storage"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
	core_errors "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors/errors_keys"
)

const viewTicketCategoryTypeAction = "view_ticket_category"

type AdminSrv interface {
	GetTicketsByCategoryIDs(ctx context.Context, employeeID int64, req models.GetTicketsByCategoryIDsRequest) rest_data.RestData
	GetCenterTickets(ctx context.Context, employeeID int64, req models.GetCenterTicketsRequest) rest_data.RestData
	GetViewTickets(ctx context.Context, employeeID int64) rest_data.RestData
	GetCenterTicketIDs(ctx context.Context, employeeID int64) rest_data.RestData
	GetCenterTicketByTicketIDs(ctx context.Context, employeeID int64, req models.GetCenterTicketByTicketIDsRequest) rest_data.RestData
}

type adminSrv struct {
	storage      storage.AdminStorage
	ticketAccess *access.TicketAccessChecker
	chatMapper   TicketListChatMapper
	errBuilder   core_errors.ErrorBuilder
}

func NewAdminSrv(
	adminStorage storage.AdminStorage,
	redisClient RedisClient,
	resourceClient ResourceEmployeeAccessClient,
	ticketInfoStorage storage.TicketsStorage,
	chatMapper TicketListChatMapper,
	errBuilder core_errors.ErrorBuilder,
) AdminSrv {
	return &adminSrv{
		storage:      adminStorage,
		ticketAccess: access.NewTicketAccessChecker(redisClient, resourceClient, ticketInfoStorage),
		chatMapper:   chatMapper,
		errBuilder:   errBuilder,
	}
}

func (s *adminSrv) GetTicketsByCategoryIDs(ctx context.Context, employeeID int64, req models.GetTicketsByCategoryIDsRequest) rest_data.RestData {
	accessibleCategories, rdError := s.getAccessibleCategoriesByAction(ctx, employeeID, req.TypeAction)
	if rdError != nil {
		return *rdError
	}

	filteredCategories := filterCategories(req.CategoryIDs, accessibleCategories)
	if len(filteredCategories) == 0 {
		return rest_data.RestData{HttpResultCode: http.StatusNoContent}
	}

	return s.storage.GetTicketsByCategories(filteredCategories)
}

func (s *adminSrv) GetCenterTickets(ctx context.Context, employeeID int64, req models.GetCenterTicketsRequest) rest_data.RestData {
	accessibleCategories, rdError := s.getAccessibleCategoriesByAction(ctx, employeeID, req.TypeAction)
	if rdError != nil {
		return *rdError
	}

	filteredCategories := filterCategories(req.CategoryIDs, accessibleCategories)
	if len(filteredCategories) == 0 {
		return rest_data.RestData{HttpResultCode: http.StatusNoContent}
	}

	rd := s.storage.GetCenterTickets(filteredCategories)
	if rd.HasError() || rd.DataEmpty() {
		return rd
	}

	res, err := s.chatMapper.MapTicketListWithChatInfo(ctx, rd.GetData(), employeeID)
	if err != nil {
		logrus.Errorf("[GetCenterTickets] MapTicketListWithChatInfo error: %v", err)
		return rd
	}
	rd.Data = &res
	return rd
}

func (s *adminSrv) GetViewTickets(ctx context.Context, employeeID int64) rest_data.RestData {
	accessibleCategories, rdError := s.getAccessibleCategoriesByAction(ctx, employeeID, viewTicketCategoryTypeAction)
	if rdError != nil {
		return *rdError
	}
	if len(accessibleCategories) == 0 {
		return rest_data.RestData{HttpResultCode: http.StatusNoContent}
	}

	rd := s.storage.GetCenterTickets(accessibleCategories)
	if rd.HasError() || rd.DataEmpty() {
		return rd
	}

	res, err := s.chatMapper.MapTicketListWithChatInfo(ctx, rd.GetData(), employeeID)
	if err != nil {
		logrus.Errorf("[GetViewTickets] MapTicketListWithChatInfo error: %v", err)
		return rd
	}
	rd.Data = &res
	return rd
}

func (s *adminSrv) GetCenterTicketIDs(ctx context.Context, employeeID int64) rest_data.RestData {
	accessibleCategories, rdError := s.getAccessibleCategoriesByAction(ctx, employeeID, viewTicketCategoryTypeAction)
	if rdError != nil {
		return *rdError
	}
	if len(accessibleCategories) == 0 {
		return rest_data.RestData{HttpResultCode: http.StatusNoContent}
	}

	return s.storage.GetCenterTicketIDs(accessibleCategories)
}

func (s *adminSrv) GetCenterTicketByTicketIDs(ctx context.Context, employeeID int64, req models.GetCenterTicketByTicketIDsRequest) rest_data.RestData {
	accessibleCategories, rdError := s.getAccessibleCategoriesByAction(ctx, employeeID, viewTicketCategoryTypeAction)
	if rdError != nil {
		return *rdError
	}
	if len(accessibleCategories) == 0 {
		return rest_data.RestData{HttpResultCode: http.StatusNoContent}
	}

	return s.storage.GetCenterTicketByTicketIDs(req.TicketIDs, accessibleCategories)
}

func (s *adminSrv) getAccessibleCategoriesByAction(ctx context.Context, employeeID int64, typeAction string) ([]int64, *rest_data.RestData) {
	accessibleCategories, err := s.ticketAccess.GetAccessibleCategories(ctx, employeeID, typeAction)
	if err != nil {
		rd := s.errBuilder.BuildError(errors_keys.Err500ReadDbResponseWrong, err)
		return nil, &rd
	}
	return accessibleCategories, nil
}

func filterCategories(requested []int64, allowed []int64) []int64 {
	if len(requested) == 0 || len(allowed) == 0 {
		return nil
	}

	allowedMap := make(map[int64]struct{}, len(allowed))
	for _, categoryID := range allowed {
		allowedMap[categoryID] = struct{}{}
	}

	filtered := make([]int64, 0, len(requested))
	for _, categoryID := range requested {
		if _, ok := allowedMap[categoryID]; ok {
			filtered = append(filtered, categoryID)
		}
	}
	return filtered
}
