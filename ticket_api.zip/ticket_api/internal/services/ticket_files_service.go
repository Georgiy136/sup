package services

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"

	jsoniter "github.com/json-iterator/go"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/access"
	custom_errors "gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/common"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/models"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/storage"
	"gitlab.wildberries.ru/wbwh/support/utils.git/access_actions"
	"gitlab.wildberries.ru/wbwh/support/utils.git/support_err_keys"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
	core_errors "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors/errors_keys"
)

type TicketFilesSrv interface {
	GetUploadFileLink(ctx context.Context, employeeID int64, req models.GetUploadFileLinkRequest) rest_data.RestData
	CompleteFileUpload(ctx context.Context, employeeID int64, req models.CompleteFileUploadRequest) rest_data.RestData
	GetFileDownloadURL(ctx context.Context, employeeID int64, req models.GetFileDownloadURLRequest) rest_data.RestData
	CancelFileUpload(ctx context.Context, employeeID int64, req models.CancelFileUploadRequest) rest_data.RestData
}

type ticketFilesSrv struct {
	fileManager  FileManagerClient
	ticketAccess *access.TicketAccessChecker
	errBuilder   core_errors.ErrorBuilder
}

func NewTicketFilesSrv(
	redisClient RedisClient,
	resourceClient ResourceEmployeeAccessClient,
	fileManager FileManagerClient,
	ticketsStorage storage.TicketsStorage,
	errBuilder core_errors.ErrorBuilder,
) TicketFilesSrv {
	return &ticketFilesSrv{
		fileManager:  fileManager,
		ticketAccess: access.NewTicketAccessChecker(redisClient, resourceClient, ticketsStorage),
		errBuilder:   errBuilder,
	}
}

func (s *ticketFilesSrv) GetUploadFileLink(ctx context.Context, employeeID int64, req models.GetUploadFileLinkRequest) rest_data.RestData {
	data, err := s.fileManager.InitUpload(ctx, employeeID, models.FileManagerInitUploadRequest{
		FileName:   req.FileName,
		FileSize:   req.FileSize,
		MimeType:   req.MimeType,
		EntityType: models.EntityTypeTicketAttachment,
	})
	if err != nil {
		return s.handleClientError(err)
	}

	return toObjectRestData(data, s.errBuilder)
}

func (s *ticketFilesSrv) CompleteFileUpload(ctx context.Context, employeeID int64, req models.CompleteFileUploadRequest) rest_data.RestData {
	err := s.fileManager.ConfirmUpload(ctx, employeeID, models.FileManagerConfirmUploadRequest{
		UploadID: req.UploadID,
		FileID:   req.FileID,
	})
	if err != nil {
		return s.handleClientError(err)
	}
	return rest_data.RestData{HttpResultCode: http.StatusNoContent}
}

func (s *ticketFilesSrv) GetFileDownloadURL(ctx context.Context, employeeID int64, req models.GetFileDownloadURLRequest) rest_data.RestData {
	hasAccess, err := s.ticketAccess.HasEmployeeTicketAccess(
		ctx,
		employeeID,
		req.TicketID,
		access_actions.TypeActionViewTicketCategory,
		access_actions.TypeActionStatusApproveCategory,
		access_actions.TypeActionStatusPerformCategory,
	)
	if err != nil {
		if errors.Is(err, custom_errors.ErrTicketNotFound) {
			return s.errBuilder.BuildError(support_err_keys.KeyErrorTicketNotFound, err)
		}
		return s.errBuilder.BuildError(errors_keys.ErrVldRequestBodyWrong, fmt.Errorf("check ticket access error: %w", err))
	}
	if !hasAccess {
		return s.errBuilder.BuildError(errors_keys.AuthErrCritTokenNotAllowed, errors.New("no access to download file for ticket"))
	}

	data, err := s.fileManager.GetDownloadURL(ctx, employeeID, req.FileID)
	if err != nil {
		return s.handleClientError(err)
	}

	return toObjectRestData(data, s.errBuilder)
}

func (s *ticketFilesSrv) CancelFileUpload(ctx context.Context, employeeID int64, req models.CancelFileUploadRequest) rest_data.RestData {
	err := s.fileManager.CancelUpload(ctx, employeeID, models.FileManagerCancelUploadRequest{
		UploadID: req.UploadID,
		FileID:   req.FileID,
	})
	if err != nil {
		return s.handleClientError(err)
	}
	return rest_data.RestData{HttpResultCode: http.StatusNoContent}
}

func (s *ticketFilesSrv) handleClientError(err error) rest_data.RestData {
	if rd := custom_errors.ToRestData(err); rd != nil {
		return *rd
	}
	return s.errBuilder.BuildError(core_errors.ErrorKey(errors_keys.ErrorKeyServiceError), err)
}

func toObjectRestData(data any, errBuilder core_errors.ErrorBuilder) rest_data.RestData {
	raw, err := jsoniter.Marshal(data)
	if err != nil {
		return errBuilder.BuildError(errors_keys.Err500MarshalWrong, fmt.Errorf("marshal response data error: %w", err))
	}

	result := json.RawMessage(raw)
	return rest_data.RestData{
		HttpResultCode: http.StatusOK,
		Data:           &result,
	}
}
