package template

import (
	"context"

	jsoniter "github.com/json-iterator/go"
	"github.com/sirupsen/logrus"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs"
)

const (
	defaultSupportSiteURL = "https://support.wbwh.tech"
)

var (
	SupportSiteURL string
)

type config struct {
	SiteUrl string `json:"site_url"`
}

func Configure(_ context.Context, cfg configs.Config) {
	const key = "service_params_key"

	exist, raw := cfg.GetByServiceKey(key)
	if !exist {
		logrus.Infof("key '%s' not found", key)
		return
	}
	var conf config
	if err := jsoniter.Unmarshal(raw, &conf); err != nil {
		logrus.Panicf("cannot unmarshal '%s' config: %v", key, err)
	}
	setServiceParams(conf)

	logrus.Debugf("'%s' configured", key)
}

func setServiceParams(conf config) {
	if conf.SiteUrl == "" {
		SupportSiteURL = defaultSupportSiteURL
		logrus.Infof("use default support site url: '%s'", SupportSiteURL)
		return
	}
	SupportSiteURL = conf.SiteUrl
}
