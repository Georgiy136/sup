package ticket_templates

var (
	PerformOnSiteTicketMessage = `\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nДанную заявку можно исполнить на [сайте](%s)`
	ConfirmOnSite              = `⚠️ Данную заявку можно исполнить только на сайте [Wh Support](%s)`

	ApproveOnSiteTicketMessage = `\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nДанную заявку можно подтвердить на [сайте](%s)`
	RejectedUnknownUser        = `\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nЗаявка была отклонена неизвестным пользователем ❌\nПодробная информация на сайте [Wh Support](%s)`
	RejectedKnownUser          = `\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n%s (%d) отклонил(-а) заявку ❌\nПодробная информация на сайте [Wh Support](%s)`
	DefaultSiteLink            = `\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\nПодробная информация на сайте [Wh Support](%s)`

	EmptyEmployeeName = "ФИО пользователя не определено"
	DefaultSystemName = "Система"

	ActionErrorMessageFormat   = "⚠️ Не удалось выполнить действие по заявке №%d:\n%s"
	ActionInternalErrorMessage = "Произошла техническая ошибка. Попробуйте позже."
)
