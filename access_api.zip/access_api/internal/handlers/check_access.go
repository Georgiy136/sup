package service

import (
	"errors"
	"fmt"

	"github.com/gin-gonic/gin"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/access_api/internal/models"
	service2 "gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/access_api/internal/service"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/access_api/internal/service/resolve"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_rest_auto_api.git/validators"
	utils "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors/errors_keys"
)

func (s *service2.Service) CheckAccess(ctx *gin.Context, params map[string]any) {
	body, ok := params[validators.BodyValidatorBODY].(*struct {
		EmployeeID int64   `json:"employee_id" binding:"required,EmployeeID"`
		CategoryID int64   `json:"category_id" binding:"required,gt=0"`
		TypeAction string  `json:"type_action" binding:"required,min=3,max=50"`
		StatusID   *string `json:"status_id" binding:"omitempty,min=1,max=3"`
	})
	if !ok {
		s.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("unsupported type"))
		return
	}
	if body == nil {
		s.errBuilder.BindError(ctx, errors_keys.ErrVldRequestBodyWrong, errors.New("passed empty body"))
		return
	}

	resourceAccessPolicy, err := s.redis.GetResourceAccessPolicy(ctx.Request.Context(), models.ResourceCompositeKey{
		CategoryID: body.CategoryID,
		TypeAction: body.TypeAction,
		StatusID:   body.StatusID,
	})
	if err != nil {
		s.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access policy for resource: %w", err))
		return
	}

	if resolve.IsAccessPolicyEmpty(resourceAccessPolicy) {
		utils.BindObjectToRestData(ctx, models.CheckAccessResult{
			Allowed:     false,
			PolicyEmpty: true,
		})
		return
	}

	employeeGroups, err := s.redis.GetAccessGroupsByEmployee(ctx.Request.Context(), body.EmployeeID)
	if err != nil {
		s.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get access groups for employee: %w", err))
		return
	}

	employeeExternalActions, err := s.resourceEmployeeAccessClient.GetAccessActionsByEmployeeID(ctx.Request.Context(), body.EmployeeID)
	if err != nil {
		s.errBuilder.BindError(ctx, errors_keys.Err500ReadDbResponseWrong, fmt.Errorf("can't get employee external actions: %w", err))
		return
	}

	utils.BindObjectToRestData(ctx, models.CheckAccessResult{
		Allowed: resolve.HasAccessByPolicy(*resourceAccessPolicy, employeeGroups, employeeExternalActions),
	})
}
