package service

import (
	"context"

	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/access_api/internal/models"
	core_errors "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors/errors_keys"
)

type Service struct {
	redis                        redisStore
	resourceEmployeeAccessClient resourceEmployeeAccessClient
	errBuilder                   core_errors.ErrorBuilder
}

func New(redis redisStore, resourceEmployeeAccessClient resourceEmployeeAccessClient) *Service {
	return &Service{
		redis:                        redis,
		resourceEmployeeAccessClient: resourceEmployeeAccessClient,
		errBuilder:                   core_errors.NewErrorBuilder(errors_keys.NewErrorsRepository().GetErrors(), nil),
	}
}

type redisStore interface {
	GetResourceAccessPolicy(ctx context.Context, resource models.ResourceCompositeKey) (*models.ResourceAccessPolicy, error)
	GetAccessGroupsByEmployee(ctx context.Context, employeeID int64) ([]int64, error)
}

type resourceEmployeeAccessClient interface {
	GetAccessActionsByEmployeeID(ctx context.Context, employeeID int64) ([]string, error)
}
