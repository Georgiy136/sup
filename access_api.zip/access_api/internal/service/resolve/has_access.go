package resolve

import (
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/access_api/internal/models"
	"gitlab.wildberries.ru/wbwh/support/utils.git/common"
)

func HasAccessByPolicy(
	accessPolicy models.ResourceAccessPolicy,
	employeeGroups []int64,
	employeeExternalActions []string,
) bool {
	if len(employeeGroups) == 0 && len(employeeExternalActions) == 0 {
		return false
	}

	employeeGroupsMap := common.SliceToMap(employeeGroups)
	employeeExternalActionsMap := common.SliceToMap(employeeExternalActions)

	for _, allowedAccessGroup := range accessPolicy.AccessGroups {
		if _, exists := employeeGroupsMap[allowedAccessGroup]; exists {
			return true
		}
	}

	for _, allowedExternalAction := range accessPolicy.ExternalActions {
		if _, exists := employeeExternalActionsMap[allowedExternalAction]; exists {
			return true
		}
	}

	return false
}

func IsAccessPolicyEmpty(resourceAP *models.ResourceAccessPolicy) bool {
	return resourceAP == nil || (len(resourceAP.AccessGroups) == 0 && len(resourceAP.ExternalActions) == 0)
}
