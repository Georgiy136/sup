package resolve_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/access_api/internal/models"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/access_api/internal/service/resolve"
	"gitlab.wildberries.ru/wbwh/support/utils.git/access_actions"
)

func TestHasAccessByPolicy(t *testing.T) {
	tests := []struct {
		name                    string
		accessPolicy            models.ResourceAccessPolicy
		employeeGroups          []int64
		employeeExternalActions []string
		expected                bool
	}{
		{
			name: "access by group",
			accessPolicy: models.ResourceAccessPolicy{
				AccessGroups:    []int64{1, 2},
				ExternalActions: []string{access_actions.TypeActionStatusApproveCategory},
			},
			employeeGroups:          []int64{2},
			employeeExternalActions: []string{},
			expected:                true,
		},
		{
			name: "access by external action",
			accessPolicy: models.ResourceAccessPolicy{
				AccessGroups:    []int64{1},
				ExternalActions: []string{access_actions.TypeActionStatusApproveCategory, access_actions.TypeActionStatusPerformCategory},
			},
			employeeGroups:          []int64{},
			employeeExternalActions: []string{access_actions.TypeActionStatusPerformCategory},
			expected:                true,
		},
		{
			name: "access by group and external action",
			accessPolicy: models.ResourceAccessPolicy{
				AccessGroups:    []int64{1},
				ExternalActions: []string{access_actions.TypeActionStatusApproveCategory},
			},
			employeeGroups:          []int64{1},
			employeeExternalActions: []string{access_actions.TypeActionStatusApproveCategory},
			expected:                true,
		},
		{
			name: "no matching groups or external actions",
			accessPolicy: models.ResourceAccessPolicy{
				AccessGroups:    []int64{1},
				ExternalActions: []string{access_actions.TypeActionStatusApproveCategory},
			},
			employeeGroups:          []int64{2},
			employeeExternalActions: []string{access_actions.TypeActionStatusPerformCategory},
			expected:                false,
		},
		{
			name: "empty employee groups and external actions",
			accessPolicy: models.ResourceAccessPolicy{
				AccessGroups:    []int64{1},
				ExternalActions: []string{access_actions.TypeActionStatusApproveCategory},
			},
			employeeGroups:          []int64{},
			employeeExternalActions: []string{},
			expected:                false,
		},
		{
			name: "empty access policy",
			accessPolicy: models.ResourceAccessPolicy{
				AccessGroups:    []int64{},
				ExternalActions: []string{},
			},
			employeeGroups:          []int64{1},
			employeeExternalActions: []string{access_actions.TypeActionStatusApproveCategory},
			expected:                false,
		},
		{
			name: "partial match only group list present",
			accessPolicy: models.ResourceAccessPolicy{
				AccessGroups:    []int64{3},
				ExternalActions: []string{},
			},
			employeeGroups:          []int64{3},
			employeeExternalActions: []string{},
			expected:                true,
		},
		{
			name: "partial match only external action list present",
			accessPolicy: models.ResourceAccessPolicy{
				AccessGroups:    []int64{},
				ExternalActions: []string{access_actions.TypeActionViewTicketCategory},
			},
			employeeGroups:          []int64{},
			employeeExternalActions: []string{access_actions.TypeActionViewTicketCategory},
			expected:                true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := resolve.HasAccessByPolicy(
				tt.accessPolicy,
				tt.employeeGroups,
				tt.employeeExternalActions,
			)

			if result != tt.expected {
				t.Errorf(
					"unexpected result: got %v, want %v",
					result,
					tt.expected,
				)
			}
		})
	}
}

func TestIsAccessPolicyEmpty(t *testing.T) {
	assert.True(t, resolve.IsAccessPolicyEmpty(nil))
	assert.True(t, resolve.IsAccessPolicyEmpty(&models.ResourceAccessPolicy{}))
	assert.False(t, resolve.IsAccessPolicyEmpty(&models.ResourceAccessPolicy{AccessGroups: []int64{1}}))
	assert.False(t, resolve.IsAccessPolicyEmpty(&models.ResourceAccessPolicy{ExternalActions: []string{"a"}}))
}
