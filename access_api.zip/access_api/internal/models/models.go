package models

type ResourceCompositeKey struct {
	CategoryID int64
	TypeAction string
	StatusID   *string
}

type ResourceAccessPolicy struct {
	ExternalActions []string
	AccessGroups    []int64
}

type CheckAccessResult struct {
	Allowed     bool `json:"allowed"`
	PolicyEmpty bool `json:"policy_empty,omitempty"`
}
