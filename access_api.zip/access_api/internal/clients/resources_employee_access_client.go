package clients

import (
	"context"
	"fmt"
	"net/http"
	"strconv"

	jsoniter "github.com/json-iterator/go"
	"github.com/valyala/fasthttp"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/access_api/internal/errors"
	"gitlab.wildberries.ru/wbwh/support/utils.git/common"
	fastclient "gitlab.wildberries.ru/wbwh/wh-core/gocore_http.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs"
)

type ResourceEmployeeAccessClient struct {
	c *fastclient.HttpClient
}

func NewResourceEmployeeAccessClient() *ResourceEmployeeAccessClient {
	return &ResourceEmployeeAccessClient{
		c: fastclient.NewHttpClient(),
	}
}

func (r *ResourceEmployeeAccessClient) Configure(ctx context.Context, config configs.Config) {
	r.c.InitHttpClient("resources_employee_access_client")(ctx, config)
}

func (r *ResourceEmployeeAccessClient) GetAccessActionsByEmployeeID(ctx context.Context, employeeID int64) ([]string, error) {
	const (
		apiKey = "GetAccessActionsByEmployeeID"
		base   = 10
	)
	params := map[string]string{
		"employee_id": strconv.FormatInt(employeeID, base),
	}

	response, err := r.c.HttpRequestWithCtx(ctx, nil, http.MethodGet, nil, apiKey, params)
	if err != nil {
		return nil, fmt.Errorf("can't get access actions by employee: %w", r.c.GenerateError(response, err, apiKey))
	}
	if response == nil {
		return nil, fmt.Errorf("can't get access actions by employee: %w", r.c.GenerateError(response, fmt.Errorf("invalid response: %w", errors.ErrResponseNil), apiKey))
	}
	defer fasthttp.ReleaseResponse(response)

	switch response.StatusCode() {
	case http.StatusOK:
		var wrapper common.DataWrapper[struct {
			ActionIds []string `json:"action_ids"`
		}]
		if err = jsoniter.Unmarshal(response.Body(), &wrapper); err != nil {
			return nil, fmt.Errorf("can't parse response body: %w", err)
		}
		return wrapper.Data.ActionIds, nil
	case http.StatusNoContent:
		return nil, nil
	default:
		return nil, fmt.Errorf("can't get access actions by employee: %w", r.c.GenerateError(response, fmt.Errorf("invalid response status %d", response.StatusCode()), apiKey))
	}
}
