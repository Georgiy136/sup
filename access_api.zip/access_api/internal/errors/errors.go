package errors

import "errors"

var ErrResponseNil = errors.New("response is nil")
