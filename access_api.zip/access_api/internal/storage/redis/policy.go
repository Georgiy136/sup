package redis

import (
	"context"
	"fmt"
	"strconv"

	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/access_api/internal/models"
)

func (c *Client) GetResourceAccessPolicy(ctx context.Context, resource models.ResourceCompositeKey) (*models.ResourceAccessPolicy, error) {
	pipe := c.Pipeline()

	externalActionsCmd := pipe.SMembers(ctx, getAccessPolicyForExternalActionsKey(resource))
	accessGroupsCmd := pipe.SMembers(ctx, getAccessPolicyForActionGroupKey(resource))

	_, err := pipe.Exec(ctx)
	if err != nil {
		return nil, fmt.Errorf("can't exec redis pipe: %w", err)
	}

	externalActionsResult, err := externalActionsCmd.Result()
	if err != nil {
		return nil, fmt.Errorf("can't get external actions from redis: %w", err)
	}

	accessGroupsResult, err := accessGroupsCmd.Result()
	if err != nil {
		return nil, fmt.Errorf("can't get access groups from redis: %w", err)
	}

	accessGroups := make([]int64, 0, len(accessGroupsResult))
	for _, groupStr := range accessGroupsResult {
		group, err := strconv.ParseInt(groupStr, 10, 64)
		if err != nil {
			return nil, fmt.Errorf("can't parse group id \"%s\": %w", groupStr, err)
		}

		accessGroups = append(accessGroups, group)
	}

	return &models.ResourceAccessPolicy{
		ExternalActions: externalActionsResult,
		AccessGroups:    accessGroups,
	}, nil
}

func (c *Client) GetAccessGroupsByEmployee(ctx context.Context, employeeID int64) ([]int64, error) {
	values, err := c.SMembers(ctx, getEmployeeActionGroupKey(employeeID)).Result()
	if err != nil {
		return nil, fmt.Errorf("can't get set from redis: %w", err)
	}

	if len(values) == 0 {
		return nil, nil
	}

	groups := make([]int64, 0, len(values))
	for _, v := range values {
		id, err := strconv.ParseInt(v, 10, 64)
		if err != nil {
			return nil, fmt.Errorf("can't parse group id \"%s\": %w", v, err)
		}
		groups = append(groups, id)
	}

	return groups, nil
}
