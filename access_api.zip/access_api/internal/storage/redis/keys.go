package redis

import (
	"fmt"

	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/access_api/internal/models"
)

func getAccessPolicyForActionGroupKey(resource models.ResourceCompositeKey) string {
	return fmt.Sprintf("access:group_ids:%d_%s_%s", resource.CategoryID, resource.TypeAction, formatOmitemptyPartKey(resource.StatusID))
}

func getAccessPolicyForExternalActionsKey(resource models.ResourceCompositeKey) string {
	return fmt.Sprintf("access:external_actions:%d_%s_%s", resource.CategoryID, resource.TypeAction, formatOmitemptyPartKey(resource.StatusID))
}

func getEmployeeActionGroupKey(employeeID int64) string {
	return fmt.Sprintf("employee_action_group:%d", employeeID)
}

func formatOmitemptyPartKey[T any](v *T) any {
	if v == nil {
		return "null"
	}
	return *v
}
