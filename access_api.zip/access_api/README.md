# AccessApi

Сервис проверки доступов новой системы Wh Support.

Проверяет, может ли сотрудник выполнить `type_action` над категорией (и опционально статусом), по политикам доступа из Redis и external actions сотрудника (группы доступа + external actions из `resources_employee_access`).

Нужен как единая точка этой проверки: бизнес-сервисы не читают Redis-политики и не ходят в `resources_employee_access` за access сами.

HTTP-контракт — [`apis.yaml`](./apis.yaml).  
Архитектурное решение — [`docs/adr-access-api.md`](./docs/adr-access-api.md).
