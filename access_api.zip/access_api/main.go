package main

import (
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/access_api/internal/clients"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/access_api/internal/service"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/access_api/internal/storage/redis"
	rest_auto_api "gitlab.wildberries.ru/wbwh/wh-core/gocore_rest_auto_api.git"
)

func main() {
	runner := rest_auto_api.NewService()

	runner.DisableJWTTokenAuth()
	runner.DisableHmacAuth()

	redisClient := redis.NewClient()
	resourceEmployeeAccessClient := clients.NewResourceEmployeeAccessClient()

	runner.RegisterConfigurableEntity(redisClient.Configure)
	runner.RegisterConfigurableEntity(resourceEmployeeAccessClient.Configure)

	srv := service.New(redisClient, resourceEmployeeAccessClient)

	runner.RegisterCustomHandler("CheckAccess", srv.CheckAccess)

	runner.Run()
}
