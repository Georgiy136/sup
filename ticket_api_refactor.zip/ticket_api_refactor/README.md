# TicketApi: переход на слоистую архитектуру (по аналогии с delivery_settings_api)

## 1. Сопоставление слоёв

| Слой | delivery_settings_api | TicketApi сейчас | TicketApi после рефакторинга |
|---|---|---|---|
| HTTP / handlers | `internal/handlers` — только парсинг, валидация, вызов сервиса | Отсутствует как отдельный слой: методы `TicketsService`/`CategoryInfo`/`AdminService` сами являются gin-хендлерами и одновременно бизнес-логикой (`internal/service/tickets.go` и др.) | `internal/handlers/{tickets,categories,admin,files}_handlers.go` — только это |
| Бизнес-логика / сервисы | `internal/services` — оркестрация, вызывает storage | Перемешана с handler'ом и с прямыми вызовами БД в одних и тех же методах (`tickets.go`, 1874 строки) | `internal/services/{tickets,categories,admin,files}_service.go` — только оркестрация, вызывает storage и access |
| Доступ к БД | `internal/storage/postgres.go` — единый `PgStorage` | `internal/service/repository.go` + десятки инлайновых `postgresql.PgSpec` прямо в `tickets.go`/`categories.go`/`admin.go` | `internal/storage/postgres.go` (общий `PgStorage`) + `internal/storage/{tickets,categories,admin,files}_storage.go` (имена SP и порядок параметров) |
| Проверка доступа | — (не нужен в delivery) | Уже частично выделен в `internal/access` + `internal/service/ticket_access_checker.go`, но `ticket_access_checker.go` физически лежит в пакете `service` и дёргает package-level функции из `repository.go` | `internal/access` становится единственным модулем проверки доступа: `access_resolver.go` (уже есть, чистые функции) + `access_checker.go` (переехавший `ticket_access_checker.go`, работает поверх своего storage-интерфейса, а не через "соседние" функции пакета `service`) |
| Модели | `internal/models` — `DataFromRequestX`/`DataFromResponseX` на каждую операцию | Есть модели, но handler-слой преимущественно кастует анонимные структуры прямо в теле метода | `internal/models` — по одному файлу на домен, именованные `DataFromRequestX` |
| Внешние клиенты | нет аналога | `clients/` (Redis, EmployeeAccess, FileManager) — уже отдельный слой, трогать не нужно | без изменений |
| Константы/ошибки | `internal/constant`, `internal/errors` | `internal/common/custom_errors.go` | оставить как есть по смыслу, можно переименовать `common` → `errors` для единообразия имени с delivery, это чисто косметика |

Папки `dependencies` и `middleware` из delivery_settings_api в переносе не участвуют — они про регистрацию рантайма (JWT/HMAC, DI-контейнер), в TicketApi это уже устроено иначе через `rest_auto_api.NewService()` + `RegisterCustomHandler` в `main.go`, трогать не нужно.

## 2. Что уже сделано в этом пакете (пилотный вертикальный срез — домен "категории")

Категории выбраны как пилот осознанно: это самый маленький и самый "чистый" домен (328 строк, без версионирования, без проверок доступа внутри) — на нём хорошо видно целевую форму слоя, и риск регрессии почти нулевой, т.к. каждая операция — это 1:1 проброс параметров в хранимую процедуру.

```
internal/
  storage/
    postgres.go            — общий PgStorage (Exec / ExecAndUnmarshal), аналог delivery/internal/storage
    categories_storage.go  — имена SP tickets.category_*/tickets.categorystatus_* и порядок параметров
  services/
    categories_service.go  — CategoriesSrv: оркестрация, точка для будущей бизнес-логики
  handlers/
    categories_handlers.go — разбор params, валидация, маппинг в models.DataFromRequestX
  models/
    categories_requests.go — именованные DataFromRequestX + структуры StatusInfo/AddedInformationModel
main_wiring_example.go     — как меняется регистрация хендлеров в main.go
```

Поведение (SQL, имена процедур, порядок параметров, коды ошибок) сохранено 1:1 — это перекладка по слоям, а не изменение логики.

### Важный нюанс биндинга, который нужно учитывать при переносе ЛЮБОГО хендлера

`GetCategoryInfoByIDV2`, `GetCategoryStatusesInfo`, `CopyCategoryTicket`, `CopyCategorySettings`, `MoveCategory` — тело запроса кастуется из `params[validators.BodyValidatorBODY]` в **анонимную** структуру. В `apis.yaml` для таких методов есть блок `schema:`, из которого фреймворк (`gocore_rest_auto_api`) на старте строит Go-тип рефлексией (`reflect.StructOf`) и кладёт в `params[BODY]` указатель именно на этот тип. Приведение типа в хендлере сработает только если анонимная структура побитово (имена полей, типы, порядок, теги) совпадает с тем, что описано в `apis.yaml`.

Практический вывод: **эту конкретную структуру-кастинг нельзя заменить на named-тип из `models`** — она обязана остаться анонимной иliteral. Пример — `UpdateCategoryStatus` в `categories_handlers.go`: анонимная структура с полным деревом вложенности сохранена как есть, а сразу после успешного `ok` она одним проходом мапится в `models.DataFromRequestUpdateCategoryStatus` — и дальше (сервис, storage) уже работает только с именованными моделями. Это правило одинаково применимо ко всем доменам, включая `tickets.go` (там таких кастов десятки, в том числе многократно продублированных между V1/V2/V3).

Для эндпоинтов, которые вместо `BODY` используют `RawBODY` + `jsoniter.Unmarshal` (`AddCategory`, `UpdateCategory`) такого ограничения нет — там можно и нужно unmarshal'ить сразу в `models.*Request`, что уже сделано.

## 3. План переноса остальных доменов

Остальные ~5000 строк переносить рекомендую в этом порядке — от простого к сложному и от изолированного к связанному:

1. **files** (`internal/service/ticket_files.go`, 197 строк) — работает с `FileManagerClientInterface`, минимум веток. Второй кандидат после categories.
2. **admin** (`internal/service/admin.go`, 317 строк) — набор Get-эндпоинтов для админки, в основном чтение.
3. **access** — сначала перенести `ticket_access_checker.go` из пакета `service` в пакет `access` (он и так почти не зависит от остального `service`, кроме двух package-level функций `getTicketCommonInfo`/`filterCategoryStatusAccessByCategory` из `repository.go` — их нужно переопределить как метод нового `internal/storage/tickets_storage.go` и передавать явно через интерфейс, а не через "соседство пакетов").
4. **tickets** (`internal/service/tickets.go`, 1874 строки) — самый большой и самый рискованный кусок, делать в самом конце и по частям (сценариями, а не файлом целиком): сначала `Create*`, потом `Perform*`/`Approve*`/`Reject*`/`Book*`, потом Get/список-эндпоинты. На каждом шаге — переносить в `handlers`/`services`/`storage` ровно один сценарий (все его версии сразу, см. ниже), покрывать существующими `tests/e2e` и `tests/http` перед мержем.

Общее правило переноса метода: handler забирает анонимную структуру из `params[BODY]` без изменений → маппит в `models.DataFromRequestX` → зовёт один метод сервиса → сервис зовёт `access` (если нужна проверка прав) и `storage` → storage знает имя SP и порядок параметров и ничего больше.

## 4. Устранение версионирования (V1/V2/V3)

Сейчас `CreateTicket`/`CreateTicketV2`/`CreateTicketV3` (и аналогично `PerformTicket*`, `ApproveTicket*`, `RejectTicket*`, `BookTicket*`) — это не "версии API" в смысле контракта, а исторически накопленные варианты одной операции с разной бизнес-логикой внутри (например, `CreateTicketV2` добавляет проверку `isPublicCategory` через `resourceAccessPolicy`, а `CreateTicket` — нет). Проблема не в том, что версий несколько, а в том, что непонятно, чем они отличаются, потому что отличия зарыты внутри почти идентичных 60-строчных функций.

Предлагаемый подход при переносе каждого такого сценария в новый слой:

- В `handlers` оставить по хендлеру на версию (это часть публичного контракта API, менять нельзя не согласовав с фронтом/потребителями) — но каждый хендлер только парсит и маппит, разницы в бизнес-логике там быть не должно.
- В `services` — один метод с явно читаемыми опциями вместо трёх скопированных функций, например:

  ```go
  type CreateTicketOptions struct {
      CheckPublicCategoryAccess bool // было: только в V2/V3
      ReserveTicketID           bool // было: только в V3
  }

  func (s *ticketsSrv) CreateTicket(data models.DataFromRequestCreateTicket, opts CreateTicketOptions) rest_data.RestData
  ```

  Хендлер `CreateTicketV3` вызывает `CreateTicket(data, CreateTicketOptions{CheckPublicCategoryAccess: true, ReserveTicketID: true})`, `CreateTicket` (V1) — с `opts` по умолчанию. Дублирование кода исчезает, а разница между версиями становится явной и читается в одном месте, а не восстанавливается построчным diff'ом трёх функций.
- Как только видно, что старая версия (обычно V1) реально не используется потребителями — это уже вопрос вывода эндпоинта из `apis.yaml` и `main.go`, отдельная задача не техническая, а продуктовая/коммуникационная с потребителями API.

## 5. Что не переносится / не меняется в этом заходе

- `clients/*` (Redis, EmployeeAccess, FileManagerApi) — уже отдельный слой, соответствует `internal/storage`-по-духу для внешних HTTP/Redis-зависимостей, трогать не нужно.
- `configs/`, `apis.yaml`, контракты — не меняются, т.к. это HTTP-контракт наружу.
- `internal/validators/url_validator.go` — уже отдельный, самодостаточный модуль.
- `dependencies/` и `middleware/` — по вашей вводной, не переносим по аналогии с delivery.
