package storage

import (
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/models"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
)

// CategoriesStorage — весь доступ к БД для домена "категории". Единственное место,
// где встречаются имена хранимых процедур tickets.category_*/tickets.categorystatus_*.
// Раньше эти имена были раскиданы прямо по internal/service/categories.go вперемешку
// с парсингом HTTP-запроса.
type CategoriesStorage interface {
	GetCategoryStatusInfoByID(categoryID int64, statusID *string) rest_data.RestData
	AddCategory(name string, parentCategoryID *int64, actionID *string, employeeID int64, isActive bool) rest_data.RestData
	UpdateCategoryStatus(categoryID int64, statusInfoJSON string, employeeID int64) rest_data.RestData
	GetCategoriesTree(employeeID int64) rest_data.RestData
	GetCategoryStatusesByCategory(categoryID int64) rest_data.RestData
	UpdateCategory(req models.UpdateCategoryRequest, employeeID int64) rest_data.RestData
	CopyCategoryTicket(categoryID, parentCategoryID, employeeID int64) rest_data.RestData
	CopyCategorySettings(sourceCategoryID, targetCategoryID, employeeID int64) rest_data.RestData
	MoveCategory(categoryID, parentCategoryID, employeeID int64) rest_data.RestData
}

type categoriesStorage struct {
	pg PgStorage
}

func NewCategoriesStorage(pg PgStorage) CategoriesStorage {
	return &categoriesStorage{pg: pg}
}

func (s *categoriesStorage) GetCategoryStatusInfoByID(categoryID int64, statusID *string) rest_data.RestData {
	const sp = "tickets.categorystatus_getbystatus"
	if statusID == nil {
		return s.pg.Exec(sp, categoryID)
	}
	return s.pg.Exec(sp, categoryID, statusID)
}

func (s *categoriesStorage) AddCategory(name string, parentCategoryID *int64, actionID *string, employeeID int64, isActive bool) rest_data.RestData {
	const sp = "tickets.category_add"
	return s.pg.Exec(sp, name, parentCategoryID, actionID, employeeID, isActive)
}

func (s *categoriesStorage) UpdateCategoryStatus(categoryID int64, statusInfoJSON string, employeeID int64) rest_data.RestData {
	const sp = "tickets.categorystatus_upd"
	return s.pg.Exec(sp, categoryID, statusInfoJSON, employeeID)
}

func (s *categoriesStorage) GetCategoriesTree(employeeID int64) rest_data.RestData {
	const sp = "tickets.category_getalltree"
	return s.pg.Exec(sp, employeeID)
}

func (s *categoriesStorage) GetCategoryStatusesByCategory(categoryID int64) rest_data.RestData {
	const sp = "tickets.categorystatus_getbycategory"
	return s.pg.Exec(sp, categoryID)
}

func (s *categoriesStorage) UpdateCategory(req models.UpdateCategoryRequest, employeeID int64) rest_data.RestData {
	const sp = "tickets.category_upd"
	return s.pg.Exec(sp, req.CategoryID, req.CategoryName, req.ParentCategoryID, req.ActionID, employeeID, *req.IsDel, req.Icon, req.Color)
}

func (s *categoriesStorage) CopyCategoryTicket(categoryID, parentCategoryID, employeeID int64) rest_data.RestData {
	const sp = "tickets.category_copy"
	return s.pg.Exec(sp, categoryID, parentCategoryID, employeeID)
}

func (s *categoriesStorage) CopyCategorySettings(sourceCategoryID, targetCategoryID, employeeID int64) rest_data.RestData {
	const sp = "tickets.category_settingscopy"
	return s.pg.Exec(sp, sourceCategoryID, targetCategoryID, employeeID)
}

func (s *categoriesStorage) MoveCategory(categoryID, parentCategoryID, employeeID int64) rest_data.RestData {
	const sp = "tickets.category_move"
	return s.pg.Exec(sp, categoryID, parentCategoryID, employeeID)
}
