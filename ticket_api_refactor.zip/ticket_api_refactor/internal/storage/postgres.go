package storage

// Единая точка доступа к БД для всех доменных сервисов (categories, tickets, admin, files).
// Аналог delivery_settings_api/internal/storage/postgres.go: сервисы больше не создают
// postgresql.PgSpec и не дергают repository.* напрямую — это единственное место, которое это делает.
// Именно сюда переезжает вся логика работы с БД, размазанная сейчас по internal/service/*.go
// (см. repository.go, а также прямые вызовы postgresql.PgSpec внутри tickets.go/categories.go/admin.go).

import (
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/models"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_database.git/postgresql"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_database.git/postgresql/repository"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
)

// PgStorage — единственный интерфейс работы с Postgres для ticket_api.
// Специально не делаем разделение Procedure/Function, как в delivery_settings_api,
// потому что в ticket_api везде используется один и тот же вызов через
// repository.GetRestDataFromDb / GetRestDataFromDbAndUnmarshal.
type PgStorage interface {
	// Exec выполняет процедуру/функцию в БД и сразу отдаёт готовый rest_data.RestData
	// (тело ответа собирается на стороне БД/repository). Соответствует текущему
	// repository.GetRestDataFromDb(pg).
	Exec(sp string, params ...any) rest_data.RestData

	// ExecAndUnmarshal выполняет процедуру/функцию и распаковывает результат в dest.
	// Соответствует текущему repository.GetRestDataFromDbAndUnmarshal(pg, dest).
	// Используется там, где сервису нужен типизированный Go-результат для дальнейшей
	// бизнес-логики (а не просто проброс ответа БД в HTTP-ответ).
	ExecAndUnmarshal(sp string, dest any, params ...any) rest_data.RestData
}

type pgStorage struct {
	databaseKey string
}

// NewPgStorage создаёт storage для конкретной БД (для ticket_api это всегда
// models.SupportPgDatabaseKey, но параметр оставлен явным, чтобы не завязываться на константу
// намертво и не плодить копипасту при появлении второй БД).
func NewPgStorage(databaseKey string) PgStorage {
	return &pgStorage{databaseKey: databaseKey}
}

// NewSupportPgStorage — удобный конструктор под единственную БД сервиса.
func NewSupportPgStorage() PgStorage {
	return NewPgStorage(models.SupportPgDatabaseKey)
}

func (p *pgStorage) Exec(sp string, params ...any) rest_data.RestData {
	pg := new(postgresql.PgSpec)
	pg.SetDatabaseKey(p.databaseKey)
	pg.SetStoredProcedureName(sp)
	pg.SetParams(params...)

	return repository.GetRestDataFromDb(pg)
}

func (p *pgStorage) ExecAndUnmarshal(sp string, dest any, params ...any) rest_data.RestData {
	pg := new(postgresql.PgSpec)
	pg.SetDatabaseKey(p.databaseKey)
	pg.SetStoredProcedureName(sp)
	pg.SetParams(params...)

	return repository.GetRestDataFromDbAndUnmarshal(pg, dest)
}
