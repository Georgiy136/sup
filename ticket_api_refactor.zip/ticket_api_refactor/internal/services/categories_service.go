package services

import (
	"fmt"

	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/models"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/storage"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
	core_errors "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors/errors_keys"

	jsoniter "github.com/json-iterator/go"
)

// CategoriesSrv — весь бизнес-слой для домена "категории". Не знает про gin.Context,
// не парсит тело запроса, не строит postgresql.PgSpec — только оркестрация.
// Сейчас (как и в оригинале) это просто проброс в storage, но именно сюда, а не в
// handler, добавляется любая будущая бизнес-логика (например, доп. проверки перед
// добавлением категории), без риска задеть разбор HTTP или SQL.
type CategoriesSrv interface {
	GetCategoryInfoByID(data models.DataFromRequestGetCategoryInfoByID) rest_data.RestData
	AddCategory(req models.AddCategoryRequest, employeeID int64) rest_data.RestData
	UpdateCategoryStatus(data models.DataFromRequestUpdateCategoryStatus) rest_data.RestData
	GetCategoriesTree(employeeID int64) rest_data.RestData
	GetCategoryStatusesInfo(data models.DataFromRequestGetCategoryStatusesInfo) rest_data.RestData
	UpdateCategory(req models.UpdateCategoryRequest, employeeID int64) rest_data.RestData
	CopyCategoryTicket(data models.DataFromRequestCopyCategoryTicket) rest_data.RestData
	CopyCategorySettings(data models.DataFromRequestCopyCategorySettings) rest_data.RestData
	MoveCategory(data models.DataFromRequestMoveCategory) rest_data.RestData
}

type categoriesSrv struct {
	storage    storage.CategoriesStorage
	errBuilder core_errors.ErrorBuilder
}

func NewCategoriesSrv(categoriesStorage storage.CategoriesStorage, errBuilder core_errors.ErrorBuilder) CategoriesSrv {
	return &categoriesSrv{
		storage:    categoriesStorage,
		errBuilder: errBuilder,
	}
}

func (c *categoriesSrv) GetCategoryInfoByID(data models.DataFromRequestGetCategoryInfoByID) rest_data.RestData {
	return c.storage.GetCategoryStatusInfoByID(data.CategoryID, data.StatusID)
}

func (c *categoriesSrv) AddCategory(req models.AddCategoryRequest, employeeID int64) rest_data.RestData {
	return c.storage.AddCategory(req.CategoryName, req.ParentCategoryID, req.ActionID, employeeID, *req.IsActive)
}

func (c *categoriesSrv) UpdateCategoryStatus(data models.DataFromRequestUpdateCategoryStatus) rest_data.RestData {
	statusInfoJSON, err := jsoniter.Marshal(data.StatusInfo)
	if err != nil {
		return c.errBuilder.BuildError(errors_keys.Err500MarshalWrong, fmt.Errorf("can't marshal status info: %w", err))
	}

	return c.storage.UpdateCategoryStatus(data.CategoryID, string(statusInfoJSON), data.EmployeeID)
}

func (c *categoriesSrv) GetCategoriesTree(employeeID int64) rest_data.RestData {
	return c.storage.GetCategoriesTree(employeeID)
}

func (c *categoriesSrv) GetCategoryStatusesInfo(data models.DataFromRequestGetCategoryStatusesInfo) rest_data.RestData {
	return c.storage.GetCategoryStatusesByCategory(data.CategoryID)
}

func (c *categoriesSrv) UpdateCategory(req models.UpdateCategoryRequest, employeeID int64) rest_data.RestData {
	return c.storage.UpdateCategory(req, employeeID)
}

func (c *categoriesSrv) CopyCategoryTicket(data models.DataFromRequestCopyCategoryTicket) rest_data.RestData {
	return c.storage.CopyCategoryTicket(data.CategoryID, data.ParentCategoryID, data.EmployeeID)
}

func (c *categoriesSrv) CopyCategorySettings(data models.DataFromRequestCopyCategorySettings) rest_data.RestData {
	return c.storage.CopyCategorySettings(data.SourceCategoryID, data.TargetCategoryID, data.EmployeeID)
}

func (c *categoriesSrv) MoveCategory(data models.DataFromRequestMoveCategory) rest_data.RestData {
	return c.storage.MoveCategory(data.CategoryID, data.ParentCategoryID, data.EmployeeID)
}
