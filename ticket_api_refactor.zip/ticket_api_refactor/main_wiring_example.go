// Пример того, как меняется main.go при переходе на слои (только фрагмент,
// относящийся к категориям — остальные домены подключаются по той же схеме).
//
// БЫЛО:
//
//   srvCategories := service.NewCategoryInfo()
//   runner.RegisterCustomHandler("AddCategory", srvCategories.AddCategory)
//   runner.RegisterCustomHandler("GetCategoryInfoByIDV2", srvCategories.GetCategoryInfoByIDV2)
//   ...
//
// СТАЛО:

package main

import (
	"github.com/go-playground/validator/v10"

	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/handlers"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/services"
	"gitlab.wildberries.ru/wbwh/support/backend/wh-support.git/ticket_api/internal/storage"
	rest_auto_api "gitlab.wildberries.ru/wbwh/wh-core/gocore_rest_auto_api.git"
	core_errors "gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors/errors_keys"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_validators.git"
)

func wireCategories(runner *rest_auto_api.Service, valid *validator.Validate, errBuilder core_errors.ErrorBuilder) {
	pg := storage.NewSupportPgStorage()

	categoriesStorage := storage.NewCategoriesStorage(pg)
	categoriesSrv := services.NewCategoriesSrv(categoriesStorage, errBuilder)
	categoriesHandler := handlers.NewCategoriesHandler(categoriesSrv, valid, errBuilder)

	runner.RegisterCustomHandler("AddCategory", categoriesHandler.AddCategory)
	runner.RegisterCustomHandler("GetCategoryInfoByIDV2", categoriesHandler.GetCategoryInfoByIDV2)
	runner.RegisterCustomHandler("UpdateCategoryStatus", categoriesHandler.UpdateCategoryStatus)
	runner.RegisterCustomHandler("UpdateCategory", categoriesHandler.UpdateCategory)
	runner.RegisterCustomHandler("GetCategoriesTree", categoriesHandler.GetCategoriesTree)
	runner.RegisterCustomHandler("GetCategoryStatusesInfo", categoriesHandler.GetCategoryStatusesInfo)
	runner.RegisterCustomHandler("CopyCategoryTicket", categoriesHandler.CopyCategoryTicket)
	runner.RegisterCustomHandler("CopyCategorySettings", categoriesHandler.CopyCategorySettings)
	runner.RegisterCustomHandler("MoveCategory", categoriesHandler.MoveCategory)
}

// В самом main() один общий validator.New() + InitializeCustomValidatorsV10 и один
// общий errBuilder создаются один раз и передаются во все wireX(...) для всех доменов
// (categories, tickets, admin, files) — так же, как раньше NewCategoryInfo()/
// NewTicketsService()/... каждый создавал свой validator и errBuilder заново.
